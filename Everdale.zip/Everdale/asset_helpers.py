
from __future__ import annotations

import random
import pygame
import os
import math
from pathlib import Path


class TextureBank:
    def __init__(self, tile_size: int) -> None:
        self.ts = tile_size
        self.rng = random.Random(42)
        self._tiles: dict[int, pygame.Surface] = {}
        self._build()

    def _noise_tile(self, base: tuple[int, int, int], spread: int = 18) -> pygame.Surface:
        s = pygame.Surface((self.ts, self.ts))
        for y in range(self.ts):
            for x in range(self.ts):
                n = self.rng.randint(-spread, spread)
                c = (max(0, min(255, base[0] + n)), max(0, min(255, base[1] + n)), max(0, min(255, base[2] + n)))
                s.set_at((x, y), c)
        return s

    def _build(self) -> None:
        grass = self._noise_tile((68, 124, 72), 12)
        for _ in range(28):
            pygame.draw.circle(grass, (54, 109, 60), (self.rng.randint(0, self.ts - 1), self.rng.randint(0, self.ts - 1)), 1)
        for _ in range(16):
            start = (self.rng.randint(0, self.ts - 1), self.rng.randint(0, self.ts - 1))
            end = (min(self.ts - 1, start[0] + self.rng.randint(-3, 3)), min(self.ts - 1, start[1] + self.rng.randint(-3, 3)))
            pygame.draw.line(grass, (76, 135, 72), start, end, 1)
        path = self._noise_tile((142, 118, 88), 10)
        water = self._noise_tile((66, 117, 182), 14)
        rock = self._noise_tile((104, 108, 116), 9)
        floor = self._noise_tile((104, 92, 76), 8)
        ruins = self._noise_tile((116, 108, 100), 10)
        bridge = self._noise_tile((130, 93, 65), 9)
        fence = self._noise_tile((137, 117, 87), 6)
        cliff = self._noise_tile((120, 98, 72), 12)
        waterfall = self._noise_tile((162, 205, 231), 10)
        deep_water = self._noise_tile((42, 78, 118), 12)
        sand = self._noise_tile((192, 168, 104), 10)
        building = self._noise_tile((209, 172, 116), 10)
        tree = self._noise_tile((36, 84, 46), 10)
        pygame.draw.circle(tree, (25, 64, 35), (self.ts // 2, self.ts // 2), self.ts // 3)
        pygame.draw.line(cliff, (97, 74, 56), (2, self.ts - 4), (self.ts - 4, self.ts - 4), 3)
        pygame.draw.line(cliff, (162, 138, 108), (2, self.ts - 8), (self.ts - 4, self.ts - 8), 1)
        for i in range(0, self.ts, 4):
            brightness = 220 + self.rng.randint(-12, 12)
            pygame.draw.line(waterfall, (brightness, brightness, 255), (i, 0), (i, self.ts), 1)
        for _ in range(6):
            px = self.rng.randint(2, self.ts - 4)
            pygame.draw.circle(deep_water, (110, 150, 190), (px, self.rng.randint(2, self.ts - 4)), 1)
        for _ in range(8):
            pygame.draw.line(sand, (208, 183, 125), (self.rng.randint(0, self.ts - 1), self.rng.randint(0, self.ts - 1)), (self.rng.randint(0, self.ts - 1), self.rng.randint(0, self.ts - 1)), 1)
        pygame.draw.arc(sand, (219, 196, 140), pygame.Rect(2, self.ts - 10, self.ts - 4, 8), 3.14, 6.28, 1)
        pygame.draw.rect(building, (189, 148, 78), pygame.Rect(2, 2, self.ts - 4, self.ts // 2), border_radius=4)
        pygame.draw.rect(building, (160, 120, 60), pygame.Rect(self.ts // 2 - 6, self.ts // 2 + 2, 10, self.ts // 2 - 6), border_radius=2)
        pygame.draw.line(building, (230, 220, 190), (4, 4), (self.ts - 6, 4), 1)
        for i in range(2, self.ts - 2, 6):
            pygame.draw.line(bridge, (150, 107, 63), (i, self.ts // 2), (i + 2, self.ts // 2), 2)
        for i in range(4, self.ts - 4, 6):
            pygame.draw.line(fence, (114, 88, 62), (i, 2), (i, self.ts - 2), 2)
        self._tiles = {
            0: grass,
            1: path,
            2: water,
            3: tree,
            4: rock,
            5: floor,
            6: ruins,
            7: bridge,
            8: fence,
            9: cliff,
            10: waterfall,
            11: deep_water,
            12: sand,
            13: building,
        }

    def tile(self, tile_id: int, anim_time: float) -> pygame.Surface:
        base = self._tiles[tile_id].copy()
        if tile_id == 2:
            # water shimmer
            y = int((anim_time * 35) % self.ts)
            pygame.draw.line(base, (170, 220, 255), (0, y), (self.ts, y), 1)
            y2 = int((anim_time * 22 + 7) % self.ts)
            pygame.draw.line(base, (145, 190, 230), (0, y2), (self.ts, y2), 1)
            for x in range(2, self.ts, 7):
                offset = int(2 * math.sin((anim_time + x) * 0.5))
                pygame.draw.line(base, (125, 170, 220), (x, 0), (x, self.ts), 1)
        elif tile_id == 10:
            # moving waterfall
            x = int((anim_time * 50) % self.ts)
            pygame.draw.line(base, (240, 255, 255), (x, 0), (x, self.ts), 2)
            pygame.draw.line(base, (200, 230, 255), (x + 3, 0), (x + 3, self.ts), 1)
        elif tile_id == 11:
            for i in range(0, self.ts, 6):
                pygame.draw.line(base, (80, 110, 155), (i, 0), (i, self.ts), 1)
            bubble_x = int((anim_time * 15) % self.ts)
            bubble_y = self.ts // 4 + int(3 * math.sin(anim_time * 2))
            pygame.draw.circle(base, (140, 180, 220), (bubble_x, bubble_y), 2)
            pygame.draw.circle(base, (150, 200, 230), ((bubble_x + 8) % self.ts, (bubble_y + 6) % self.ts), 1)
        return base


class ItemTextureBank:
    """Load and cache 32x32 item textures from assets/items/"""
    
    def __init__(self) -> None:
        self._items: dict[str, pygame.Surface] = {}
        self._load_items()
    
    def _load_items(self) -> None:
        """Load all item textures from assets/items/ directory."""
        items_dir = Path(__file__).parent / "assets" / "items"
        if not items_dir.exists():
            return
        
        for item_file in items_dir.glob("*.png"):
            try:
                surface = pygame.image.load(str(item_file)).convert_alpha()
                item_name = item_file.stem
                self._items[item_name] = surface
            except Exception as e:
                print(f"  Warning: Failed to load {item_file.name}: {e}")
    
    def get_item(self, item_id: str) -> pygame.Surface | None:
        """Get item texture, returns None if not found."""
        return self._items.get(item_id)
    
    def get_item_or_placeholder(self, item_id: str, size: int = 32) -> pygame.Surface:
        """Get item texture or create a placeholder if not found."""
        tex = self._items.get(item_id)
        if tex is not None:
            return tex
        
        # Create placeholder
        placeholder = pygame.Surface((size, size), pygame.SRCALPHA)
        color = hash(item_id) % 256, (hash(item_id) // 256) % 256, (hash(item_id) // 65536) % 256
        pygame.draw.rect(placeholder, color, (2, 2, size - 4, size - 4))
        pygame.draw.rect(placeholder, (255, 255, 255), (2, 2, size - 4, size - 4), 1)
        return placeholder


class NPCTextureBank:
    """Procedural NPC textures for old, middle-age, and child characters."""

    def __init__(self, size: int = 24) -> None:
        self.size = size
        self._textures: dict[str, pygame.Surface] = {}
        self._build()

    def _build(self) -> None:
        self._textures["old"] = self._make_old()
        self._textures["middle"] = self._make_middle()
        self._textures["child"] = self._make_child()
        self._textures["elder"] = self._textures["old"]
        self._textures["adult"] = self._textures["middle"]
        self._textures["young"] = self._textures["child"]

    def _make_old(self) -> pygame.Surface:
        surf = pygame.Surface((self.size, self.size), pygame.SRCALPHA)
        pygame.draw.circle(surf, (240, 220, 190), (self.size // 2, self.size // 2 - 2), self.size // 2 - 4)
        pygame.draw.rect(surf, (100, 90, 70), pygame.Rect(4, self.size // 2 + 1, self.size - 8, self.size // 3), border_radius=4)
        pygame.draw.circle(surf, (220, 220, 220), (self.size // 2, 6), 4)
        pygame.draw.circle(surf, (80, 60, 40), (self.size // 2 - 5, self.size // 2 - 2), 2)
        pygame.draw.circle(surf, (80, 60, 40), (self.size // 2 + 5, self.size // 2 - 2), 2)
        pygame.draw.arc(surf, (90, 70, 50), pygame.Rect(4, self.size // 2 - 2, self.size - 8, self.size // 2), 3.14, 0, 2)
        return surf

    def _make_middle(self) -> pygame.Surface:
        surf = pygame.Surface((self.size, self.size), pygame.SRCALPHA)
        pygame.draw.circle(surf, (235, 200, 150), (self.size // 2, self.size // 2 - 2), self.size // 2 - 4)
        pygame.draw.rect(surf, (120, 80, 50), pygame.Rect(4, self.size // 2 + 3, self.size - 8, self.size // 3), border_radius=3)
        pygame.draw.rect(surf, (80, 60, 40), pygame.Rect(4, 2, self.size - 8, 6), border_radius=3)
        pygame.draw.circle(surf, (70, 50, 30), (self.size // 2 - 5, self.size // 2 - 2), 2)
        pygame.draw.circle(surf, (70, 50, 30), (self.size // 2 + 5, self.size // 2 - 2), 2)
        pygame.draw.line(surf, (70, 50, 30), (self.size // 2 - 4, self.size // 2 + 4), (self.size // 2 + 4, self.size // 2 + 4), 2)
        return surf

    def _make_child(self) -> pygame.Surface:
        surf = pygame.Surface((self.size, self.size), pygame.SRCALPHA)
        pygame.draw.circle(surf, (255, 220, 180), (self.size // 2, self.size // 2 - 2), self.size // 2 - 5)
        pygame.draw.rect(surf, (180, 120, 90), pygame.Rect(4, self.size // 2 + 5, self.size - 8, self.size // 4), border_radius=3)
        pygame.draw.rect(surf, (240, 200, 140), pygame.Rect(4, 4, self.size - 8, 6), border_radius=3)
        pygame.draw.circle(surf, (60, 40, 30), (self.size // 2 - 4, self.size // 2 - 2), 2)
        pygame.draw.circle(surf, (60, 40, 30), (self.size // 2 + 4, self.size // 2 - 2), 2)
        pygame.draw.arc(surf, (70, 50, 30), pygame.Rect(6, self.size // 2, self.size - 12, self.size // 3), 3.14, 0, 1)
        pygame.draw.circle(surf, (255, 255, 255), (self.size // 2 - 2, self.size // 2 - 6), 1)
        pygame.draw.circle(surf, (255, 255, 255), (self.size // 2 + 2, self.size // 2 - 6), 1)
        return surf

    def get(self, age_group: str) -> pygame.Surface:
        return self._textures.get(age_group, self._textures["middle"])


class PlayerTextureBank:
    """Procedural player sprite sheets for four distinct character archetypes."""

    def __init__(self, size: int = 32, frame_count: int = 4) -> None:
        self.size = size
        self.frame_count = frame_count
        self._sprites: dict[str, list[list[pygame.Surface]]] = {}
        self._build()

    def _build(self) -> None:
        archetypes = {
            "human": {
                "skin": (242, 198, 160),
                "cloth": (80, 112, 166),
                "accent": (190, 176, 110),
                "hair": (78, 52, 30),
                "boot": (55, 62, 87),
            },
            "dwarf": {
                "skin": (232, 188, 146),
                "cloth": (104, 84, 65),
                "accent": (178, 116, 74),
                "hair": (68, 44, 28),
                "boot": (54, 42, 35),
            },
            "elf": {
                "skin": (235, 210, 170),
                "cloth": (76, 132, 94),
                "accent": (158, 204, 130),
                "hair": (64, 102, 88),
                "boot": (55, 76, 58),
            },
            "ranger": {
                "skin": (226, 180, 138),
                "cloth": (92, 110, 74),
                "accent": (154, 133, 93),
                "hair": (44, 38, 32),
                "boot": (54, 58, 42),
            },
        }

        for kind, palette in archetypes.items():
            self._sprites[kind] = []
            for direction in range(4):
                frames = [self._build_frame(kind, palette, direction, frame) for frame in range(self.frame_count)]
                self._sprites[kind].append(frames)

    def _build_frame(self, kind: str, palette: dict[str, tuple[int, int, int]], direction: int, frame_index: int) -> pygame.Surface:
        surf = pygame.Surface((self.size, self.size), pygame.SRCALPHA)
        animation_offset = [0, 2, 0, -2][frame_index % self.frame_count]
        head_dx = -1 if direction == 1 else 1 if direction == 2 else 0

        # Body and layout
        body_y = 14 if kind == "dwarf" else 12
        body_height = 12 if kind == "dwarf" else 14
        body_rect = pygame.Rect(10, body_y, 12, body_height)
        pygame.draw.ellipse(surf, palette["cloth"], body_rect)
        pygame.draw.rect(surf, palette["accent"], pygame.Rect(10, body_y + 6, 12, 8), border_radius=4)
        pygame.draw.circle(surf, palette["skin"], (16 + head_dx, 9), 6)
        pygame.draw.rect(surf, palette["hair"], pygame.Rect(10 + head_dx, 3, 12, 7), border_radius=4)

        # Arms and legs
        pygame.draw.rect(surf, palette["cloth"], pygame.Rect(6, 16 + animation_offset // 2, 4, 10), border_radius=3)
        pygame.draw.rect(surf, palette["cloth"], pygame.Rect(22, 16 - animation_offset // 2, 4, 10), border_radius=3)
        pygame.draw.rect(surf, palette["boot"], pygame.Rect(12 - animation_offset // 2, 24, 4, 6), border_radius=2)
        pygame.draw.rect(surf, palette["boot"], pygame.Rect(18 + animation_offset // 2, 24, 4, 6), border_radius=2)

        # Character-specific details
        if kind == "dwarf":
            pygame.draw.polygon(surf, palette["hair"], [(11, 10), (16, 20), (21, 10)])
            pygame.draw.rect(surf, palette["accent"], pygame.Rect(10, 22, 12, 4), border_radius=2)
            pygame.draw.circle(surf, palette["accent"], (16, 11), 2)
        elif kind == "elf":
            pygame.draw.polygon(surf, palette["hair"], [(6, 8), (10, 6), (10, 10)])
            pygame.draw.polygon(surf, palette["hair"], [(26, 8), (22, 6), (22, 10)])
            pygame.draw.line(surf, palette["accent"], (16, 12), (16, 24), 3)
        elif kind == "ranger":
            pygame.draw.rect(surf, palette["accent"], pygame.Rect(8, 8, 16, 10), border_radius=8)
            pygame.draw.line(surf, palette["hair"], (10, 16), (22, 10), 2)
            pygame.draw.line(surf, palette["hair"], (22, 16), (10, 22), 2)
        else:
            pygame.draw.rect(surf, palette["accent"], pygame.Rect(14, 18, 4, 8), border_radius=2)
            pygame.draw.circle(surf, palette["hair"], (16, 6), 2)

        return surf

    def get(self, kind: str, direction: int, frame: int) -> pygame.Surface:
        kind_sprites = self._sprites.get(kind, self._sprites["human"])
        return kind_sprites[direction % 4][frame % self.frame_count]


def draw_player_sprite(surf: pygame.Surface, rect: pygame.Rect, face: pygame.Vector2, anim_phase: float, hit_flash: bool) -> None:
    body = (255, 132, 132) if hit_flash else (250, 214, 152)
    pygame.draw.ellipse(surf, body, rect)
    leg_shift = int((anim_phase * 3) % 4) - 2
    pygame.draw.rect(surf, (77, 90, 116), pygame.Rect(rect.x + 4, rect.bottom - 6, 6, 4 + leg_shift))
    pygame.draw.rect(surf, (77, 90, 116), pygame.Rect(rect.right - 10, rect.bottom - 6, 6, 4 - leg_shift))
    tip = pygame.Vector2(rect.centerx, rect.centery) + face * 10
    pygame.draw.circle(surf, (44, 58, 84), (int(tip.x), int(tip.y)), 3)


def draw_enemy_sprite(surf: pygame.Surface, rect: pygame.Rect, color: tuple[int, int, int], anim_phase: float, hit_flash: bool) -> None:
    c = (255, 170, 170) if hit_flash else color
    wobble = int((anim_phase * 4) % 3) - 1
    rr = rect.inflate(0, wobble)
    pygame.draw.ellipse(surf, c, rr)

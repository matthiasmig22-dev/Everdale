from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ItemDef:
    item_id: str
    name: str
    description: str
    category: str
    value: int
    heal: int = 0
    stamina: int = 0
    power: int = 0
    defense: int = 0
    max_stack: int = 99


ITEM_DEFS: dict[str, ItemDef] = {
    "apple": ItemDef("apple", "Apple", "Crisp orchard fruit. Restores a bit of health.", "food", 8, heal=8),
    "berry": ItemDef("berry", "Wild Berries", "Sweet forest berries. Light healing.", "food", 6, heal=6),
    "mushroom": ItemDef("mushroom", "Cave Mushroom", "Earthy mushroom that restores health and stamina.", "food", 10, heal=7, stamina=12),
    "herb": ItemDef("herb", "Sun Herb", "Medicinal plant used in village remedies.", "resource", 12),
    "wood": ItemDef("wood", "Wood", "Gathered timber used for crafting.", "resource", 4),
    "string": ItemDef("string", "String", "Thin cord used for bows and tools.", "resource", 8),
    "fish": ItemDef("fish", "River Fish", "Fresh fish. Strong healing meal.", "food", 14, heal=14),
    "boat": ItemDef("boat", "Boat", "A sturdy boat found at river docks. Allows crossing calm water.", "tool", 0, max_stack=99),
    "fishing_rod": ItemDef("fishing_rod", "Fishing Rod", "A simple rod for catching river fish.", "tool", 44, max_stack=1),
    "pickaxe": ItemDef("pickaxe", "Pickaxe", "A miner's pick for extracting ore from rock.", "tool", 35, max_stack=1),
    "iron_ore": ItemDef("iron_ore", "Iron Ore", "Rough iron ore from the Dwarven Mines.", "resource", 24),
    "silver_ore": ItemDef("silver_ore", "Silver Ore", "Fine silver ore that gleams in the dark.", "resource", 38),
    "gold_ore": ItemDef("gold_ore", "Gold Ore", "Rich gold ore worth selling to the forge.", "resource", 62),
    "iron_axe": ItemDef("iron_axe", "Iron Axe", "Sturdy axe forged from iron. Strong for combat and mining.", "weapon", 120, power=6, max_stack=1),
    "gold_sword": ItemDef("gold_sword", "Gold Sword", "A lustrous blade with extra edge.", "weapon", 180, power=10, max_stack=1),
    "silver_armor": ItemDef("silver_armor", "Silver Armor", "Polished armor that offers strong protection.", "armor", 170, defense=8, max_stack=1),
    "steel_armor": ItemDef("steel_armor", "Steel Armor", "Durable armor forged in volcanic heat.", "armor", 150, defense=10, max_stack=1),
    "iron_sword": ItemDef("iron_sword", "Iron Sword", "Balanced blade for close combat.", "weapon", 90, power=8, max_stack=1),
    "traveler_bow": ItemDef("traveler_bow", "Traveler Bow", "Simple ranged weapon.", "weapon", 100, power=7, max_stack=1),
    "hearty_stew": ItemDef("hearty_stew", "Hearty Stew", "Warm meal sold by merchants. Strong heal.", "food", 30, heal=24, stamina=10),
    "minor_potion": ItemDef("minor_potion", "Minor Elixir", "Quick healing draught.", "healing", 22, heal=20),
    "stamina_tonic": ItemDef("stamina_tonic", "Stamina Tonic", "Replenishes a chunk of stamina.", "healing", 24, stamina=35),
    "ancient_core": ItemDef("ancient_core", "Ancient Core", "Strange relic from old ruins.", "rare", 120),
    "ruins_key": ItemDef("ruins_key", "Ruins Seal Key", "Unlocks the inner ruins gate.", "quest", 0, max_stack=1),
    "ancient_coin": ItemDef("ancient_coin", "Ancient Coin", "Old northern currency with mysterious markings.", "rare", 45),
    "eastern_herb": ItemDef("eastern_herb", "Eastern Herb", "Rare herb from eastern regions.", "resource", 16),
    "cave_key": ItemDef("cave_key", "Cave Key", "Unlocks deeper cave chambers.", "quest", 0, max_stack=1),
    "ancient_relic": ItemDef("ancient_relic", "Ancient Relic", "Mysterious artifact from forgotten depths.", "rare", 80),
    "northern_herb": ItemDef("northern_herb", "Northern Herb", "Frost-resistant herb from northern climes.", "resource", 14),
    "seaweed": ItemDef("seaweed", "Seaweed", "Salty seaweed harvested from coastal waters.", "food", 8, heal=6),
    "desert_herb": ItemDef("desert_herb", "Desert Herb", "Resilient herb that thrives in arid conditions.", "resource", 20),
    "cactus_fruit": ItemDef("cactus_fruit", "Cactus Fruit", "Juicy fruit from desert cacti. Hydrating and healing.", "food", 12, heal=10, stamina=8),
    "sandstone_amulet": ItemDef("sandstone_amulet", "Sandstone Amulet", "Ancient amulet carved from desert stone.", "rare", 80),
}


def get_item(item_id: str) -> ItemDef:
    return ITEM_DEFS[item_id]

from __future__ import annotations

import json
import settings


class SaveSystem:
    @staticmethod
    def exists() -> bool:
        return settings.SAVE_FILE.exists()

    @staticmethod
    def load() -> dict:
        settings.SAVE_DIR.mkdir(parents=True, exist_ok=True)
        if not settings.SAVE_FILE.exists():
            return {}
        try:
            with settings.SAVE_FILE.open("r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            return {}

    @staticmethod
    def save(data: dict) -> None:
        settings.SAVE_DIR.mkdir(parents=True, exist_ok=True)
        with settings.SAVE_FILE.open("w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    @staticmethod
    def reset() -> None:
        if settings.SAVE_FILE.exists():
            settings.SAVE_FILE.unlink()

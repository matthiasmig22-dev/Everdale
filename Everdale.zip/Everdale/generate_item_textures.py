#!/usr/bin/env python3
"""Generate detailed 32x32 pixel art textures for all game items."""

from PIL import Image, ImageDraw
import os

ASSETS_DIR = "/home/thrussianwombat/Desktop/coding projects/Everdale/assets"
ITEMS_DIR = os.path.join(ASSETS_DIR, "items")
os.makedirs(ITEMS_DIR, exist_ok=True)

def create_image(color_palette: list[tuple], size=32):
    """Create a blank 32x32 image (transparent)."""
    return Image.new('RGBA', (size, size), (0, 0, 0, 0))

def save_item(name: str, img: Image.Image):
    """Save item texture."""
    path = os.path.join(ITEMS_DIR, f"{name}.png")
    img.save(path)
    print(f"  ✓ {name}.png")

# FOOD ITEMS
def gen_apple():
    img = create_image([])
    draw = ImageDraw.Draw(img)
    # Soft shadow under apple
    draw.ellipse([7, 9, 25, 23], fill=(0, 0, 0, 48))
    # Body gradient by layered ellipses
    draw.ellipse([8, 6, 24, 20], fill=(200, 40, 40))
    draw.ellipse([9, 7, 23, 19], fill=(220, 60, 60))
    draw.ellipse([11, 8, 21, 16], fill=(240, 100, 100))
    # Specular highlight
    draw.ellipse([10, 8, 14, 12], fill=(255, 230, 230))
    # Stem and leaf with slight shading
    draw.line([15, 4, 15, 7], fill=(95, 70, 30), width=2)
    draw.polygon([(15,7),(18,9),(16,10)], fill=(50, 110, 50))
    save_item("apple", img)

def gen_berry():
    img = create_image([])
    draw = ImageDraw.Draw(img)
    # Cluster with tiny dropshadow
    berries = [(10, 8), (12, 11), (14, 8), (16, 11), (18, 8), (12, 16), (16, 16)]
    for (x, y) in berries:
        draw.ellipse([x-3, y-3, x+3, y+3], fill=(0,0,0,48))
        draw.ellipse([x-3, y-4, x+3, y+2], fill=(140,50,180))
        draw.ellipse([x-2, y-3, x+1, y+1], fill=(200,120,230))
    save_item("berry", img)

def gen_mushroom():
    img = create_image([])
    draw = ImageDraw.Draw(img)
    # Shadow under cap
    draw.ellipse([9, 12, 23, 22], fill=(0,0,0,36))
    # Cap with layered fills for depth
    draw.ellipse([8, 8, 24, 18], fill=(190,90,90))
    draw.ellipse([10, 9, 22, 16], fill=(220,120,120))
    # Stem with shading
    draw.polygon([(14, 18), (18, 18), (17, 28), (15, 28)], fill=(230,210,160))
    draw.line([(15,19),(17,19)], fill=(200,180,140), width=1)
    # Spots
    for x, y in [(11,10),(15,10),(19,10),(13,13),(18,13)]:
        draw.ellipse([x-1, y-1, x+1, y+1], fill=(255,200,200))
    save_item("mushroom", img)

def gen_fish():
    img = create_image([])
    draw = ImageDraw.Draw(img)
    # Subtle shadow under body
    draw.ellipse([9, 15, 23, 20], fill=(0,0,0,40))
    # Body with core and edge fills
    draw.polygon([(8,14),(24,12),(24,18),(8,16)], fill=(170,110,60))
    draw.polygon([(9,14),(23,13),(23,17),(9,16)], fill=(200,140,80))
    # Head highlight
    draw.ellipse([8,12,14,18], fill=(210,150,90))
    # Eye
    draw.ellipse([10,13,12,15], fill=(40,40,40))
    draw.ellipse([11,14,11.5,14.5], fill=(230,230,230))
    # Tail shading
    draw.polygon([(24,12),(28,10),(28,14),(26,12)], fill=(160,100,60))
    draw.polygon([(24,18),(28,20),(28,16),(26,18)], fill=(160,100,60))
    save_item("fish", img)

def gen_cactus_fruit():
    img = create_image([])
    draw = ImageDraw.Draw(img)
    # Fruit body
    draw.ellipse([10, 10, 22, 24], fill=(200, 180, 80))  # Yellow-green
    # Bumpy texture
    for x, y in [(11, 12), (15, 11), (19, 12), (20, 15), (19, 19), (15, 21), (11, 20), (10, 16)]:
        draw.ellipse([x-1, y-1, x+2, y+2], fill=(220, 200, 100))
    # Red accent
    draw.ellipse([14, 14, 18, 18], fill=(200, 100, 80))
    save_item("cactus_fruit", img)

def gen_seaweed():
    img = create_image([])
    draw = ImageDraw.Draw(img)
    # Wavy seaweed strands
    draw.line([(8, 26), (10, 20), (8, 14), (10, 8), (12, 10)], fill=(80, 150, 100), width=2)
    draw.line([(12, 26), (14, 18), (12, 10), (14, 6)], fill=(60, 130, 80), width=2)
    draw.line([(16, 26), (18, 16), (16, 8), (18, 4)], fill=(100, 160, 120), width=2)
    draw.line([(20, 26), (22, 18), (20, 10), (22, 6)], fill=(80, 140, 100), width=2)
    # Water effect
    draw.line([(10, 28), (22, 28)], fill=(60, 120, 180), width=2)
    save_item("seaweed", img)

def gen_hearty_stew():
    img = create_image([])
    draw = ImageDraw.Draw(img)
    # Shadow under bowl
    draw.ellipse([6, 14, 26, 26], fill=(0,0,0,40))
    # Bowl outer and inner fills
    draw.ellipse([6,10,26,22], fill=(170,110,70))
    draw.ellipse([8,12,24,20], fill=(200,140,100))
    # Stew surface and chunks
    draw.ellipse([9,13,23,19], fill=(150,100,60))
    draw.ellipse([11,14,13,16], fill=(210,120,90))
    draw.ellipse([17,15,19,17], fill=(170,130,100))
    # Steam wisps
    draw.line([(12,8),(12,4)], fill=(240,240,240), width=1)
    draw.line([(16,7),(16,3)], fill=(240,240,240), width=1)
    save_item("hearty_stew", img)

# RESOURCE ITEMS
def gen_herb():
    img = create_image([])
    draw = ImageDraw.Draw(img)
    # Stems with subtle darker back
    draw.line([(10,26),(10,12)], fill=(60,120,50), width=3)
    draw.line([(16,26),(16,10)], fill=(60,120,50), width=3)
    # Leaves with highlight polygons
    draw.polygon([(8,16),(12,12),(13,14)], fill=(120,180,100))
    draw.polygon([(14,18),(18,14),(16,16)], fill=(110,170,90))
    draw.polygon([(20,16),(24,12),(22,14)], fill=(120,180,100))
    save_item("herb", img)

def gen_wood():
    img = create_image([])
    draw = ImageDraw.Draw(img)
    # Log body with highlight
    draw.rectangle([6,8,26,14], fill=(110,70,30))
    draw.line([(6,8),(26,8)], fill=(150,110,60), width=1)
    # Cross-section rings larger layered ellipses
    draw.ellipse([10,16,22,28], fill=(160,120,70))
    draw.ellipse([12,18,20,26], fill=(130,90,50))
    draw.ellipse([14,20,18,24], fill=(160,120,70))
    save_item("wood", img)

def gen_string():
    img = create_image([])
    draw = ImageDraw.Draw(img)
    # Coiled string
    for i in range(5):
        y = 6 + i * 4
        draw.line([(8 + i, y), (24 - i, y + 2)], fill=(200, 180, 120), width=2)
    # String coil at bottom
    draw.ellipse([10, 20, 22, 28], fill=(200, 180, 120))
    draw.ellipse([12, 22, 20, 26], fill=(180, 160, 100))
    save_item("string", img)

def gen_eastern_herb():
    img = create_image([])
    draw = ImageDraw.Draw(img)
    # Exotic plant
    draw.line([(10, 26), (10, 10)], fill=(100, 180, 80), width=2)
    draw.line([(14, 26), (14, 8)], fill=(100, 180, 80), width=2)
    draw.line([(18, 26), (18, 12)], fill=(100, 180, 80), width=2)
    draw.line([(22, 26), (22, 10)], fill=(100, 180, 80), width=2)
    # Flowing leaves
    for x, y in [(6, 14), (12, 10), (16, 14), (20, 9), (26, 12)]:
        draw.polygon([(x, y), (x+3, y-2), (x+4, y+1)], fill=(150, 200, 120))
    save_item("eastern_herb", img)

def gen_northern_herb():
    img = create_image([])
    draw = ImageDraw.Draw(img)
    # Frost herb
    draw.line([(12, 26), (12, 10)], fill=(150, 180, 220), width=2)  # Blue-ish
    draw.line([(16, 26), (16, 8)], fill=(150, 180, 220), width=2)
    draw.line([(20, 26), (20, 12)], fill=(150, 180, 220), width=2)
    # Frost crystals
    for x, y in [(10, 14), (14, 12), (18, 14), (22, 11), (24, 16)]:
        draw.polygon([(x, y), (x+2, y-2), (x+2, y+2)], fill=(200, 220, 255))
    save_item("northern_herb", img)

def gen_desert_herb():
    img = create_image([])
    draw = ImageDraw.Draw(img)
    # Desert plant
    draw.line([(10, 26), (10, 12)], fill=(180, 140, 60), width=2)
    draw.line([(16, 26), (16, 10)], fill=(180, 140, 60), width=2)
    draw.line([(22, 26), (22, 14)], fill=(180, 140, 60), width=2)
    # Sandy colored leaves
    for x, y in [(8, 16), (12, 14), (14, 18), (18, 12), (20, 16), (24, 14)]:
        draw.polygon([(x, y), (x+3, y-2), (x+3, y+2)], fill=(200, 160, 80))
    save_item("desert_herb", img)

# HEALING ITEMS
def gen_minor_potion():
    img = create_image([])
    draw = ImageDraw.Draw(img)
    # Bottle glass outer and inner
    draw.ellipse([9,6,23,24], fill=(120,180,210))
    draw.ellipse([10,7,22,23], fill=(200,240,255))
    # Liquid gradient inside
    draw.ellipse([12,14,20,22], fill=(240,100,100))
    draw.ellipse([12,12,20,20], fill=(255,140,140))
    # Cork
    draw.rectangle([12,4,20,8], fill=(150,110,60))
    # Label
    draw.rectangle([13,10,19,14], fill=(255,255,220))
    draw.line([(14,11),(18,11)], fill=(120,120,120), width=1)
    save_item("minor_potion", img)

def gen_stamina_tonic():
    img = create_image([])
    draw = ImageDraw.Draw(img)
    # Bottle
    draw.rectangle([10, 8, 22, 26], fill=(100, 150, 180))
    draw.rectangle([11, 9, 21, 25], fill=(150, 200, 255))
    # Cork
    draw.rectangle([12, 4, 20, 8], fill=(150, 100, 50))
    # Liquid inside (bright yellow-green)
    draw.rectangle([12, 14, 20, 24], fill=(200, 255, 100))
    # Sparkles
    draw.line([(15, 10), (15, 14)], fill=(255, 255, 100), width=1)
    draw.line([(19, 12), (19, 16)], fill=(255, 255, 100), width=1)
    save_item("stamina_tonic", img)

# WEAPON ITEMS
def gen_iron_sword():
    img = create_image([])
    draw = ImageDraw.Draw(img)
    # Blade base and inner highlight
    draw.polygon([(14,2),(18,2),(18,20),(17,24),(15,24),(14,20)], fill=(120,120,140))
    draw.polygon([(14.5,4),(17.5,4),(17,18),(15,18)], fill=(200,200,220))
    draw.line([(15,4),(17,16)], fill=(230,230,240), width=1)
    # Cross-guard
    draw.rectangle([10,20,22,22], fill=(170,120,70))
    # Handle with wrap lines
    draw.rectangle([14,22,18,30], fill=(90,60,30))
    for y in range(24,30,2):
        draw.line([(14,y),(18,y)], fill=(120,80,40), width=1)
    save_item("iron_sword", img)

def gen_traveler_bow():
    img = create_image([])
    draw = ImageDraw.Draw(img)
    # Bow silhouette
    draw.arc([(8, 6), (14, 26)], 0, 180, fill=(100, 80, 40), width=3)
    draw.arc([(18, 6), (24, 26)], 0, 180, fill=(100, 80, 40), width=3)
    # Bow arms
    draw.line([(10, 8), (10, 24)], fill=(140, 100, 50), width=3)
    draw.line([(22, 8), (22, 24)], fill=(140, 100, 50), width=3)
    # String
    draw.line([(10, 8), (16, 16), (10, 24)], fill=(180, 140, 80), width=2)
    draw.line([(22, 8), (16, 16), (22, 24)], fill=(180, 140, 80), width=2)
    # Arrow nocked
    draw.polygon([(13, 15), (13, 17), (16, 16)], fill=(200, 100, 50))
    save_item("traveler_bow", img)

def gen_fishing_rod():
    img = create_image([])
    draw = ImageDraw.Draw(img)
    # Rod shaft and handle
    draw.line([(10, 6), (13, 26)], fill=(120, 80, 40), width=3)
    draw.line([(13, 26), (18, 30)], fill=(120, 80, 40), width=3)
    draw.line([(12, 10), (14, 12)], fill=(180, 160, 110), width=4)
    # Line and hook
    draw.line([(12, 10), (18, 2)], fill=(230, 230, 240), width=1)
    draw.line([(18, 2), (20, 6)], fill=(230, 230, 240), width=1)
    draw.ellipse([18, 4, 22, 8], outline=(200, 200, 230), width=1)
    save_item("fishing_rod", img)

def gen_pickaxe():
    img = create_image([])
    draw = ImageDraw.Draw(img)
    # Pickaxe head
    draw.rectangle([8, 12, 24, 16], fill=(120, 120, 130))
    draw.polygon([(8, 12), (6, 10), (10, 8), (14, 10)], fill=(140, 140, 160))
    draw.polygon([(24, 12), (26, 10), (22, 8), (18, 10)], fill=(140, 140, 160))
    # Handle
    draw.line([(16, 16), (16, 28)], fill=(130, 90, 50), width=3)
    draw.line([(15, 20), (17, 22)], fill=(170, 140, 90), width=1)
    save_item("pickaxe", img)

def gen_iron_ore():
    img = create_image([])
    draw = ImageDraw.Draw(img)
    # Iron ore chunk
    draw.polygon([(8, 10), (24, 12), (22, 24), (10, 26)], fill=(110, 110, 120))
    draw.polygon([(10, 12), (20, 10), (22, 22), (12, 24)], fill=(170, 160, 130))
    draw.line([(12, 14), (18, 14)], fill=(210, 200, 170), width=1)
    save_item("iron_ore", img)

def gen_silver_ore():
    img = create_image([])
    draw = ImageDraw.Draw(img)
    # Silver ore chunk
    draw.polygon([(8, 10), (24, 12), (22, 24), (10, 26)], fill=(170, 170, 190))
    draw.polygon([(10, 12), (20, 10), (22, 22), (12, 24)], fill=(220, 220, 240))
    draw.line([(12, 14), (18, 14)], fill=(240, 240, 255), width=1)
    save_item("silver_ore", img)

def gen_gold_ore():
    img = create_image([])
    draw = ImageDraw.Draw(img)
    # Gold ore chunk
    draw.polygon([(8, 10), (24, 12), (22, 24), (10, 26)], fill=(210, 170, 80))
    draw.polygon([(10, 12), (20, 10), (22, 22), (12, 24)], fill=(245, 210, 110))
    draw.line([(12, 14), (18, 14)], fill=(255, 235, 150), width=1)
    save_item("gold_ore", img)

def gen_iron_axe():
    img = create_image([])
    draw = ImageDraw.Draw(img)
    draw.polygon([(12, 8), (20, 8), (22, 16), (18, 18), (14, 18), (12, 16)], fill=(120, 120, 140))
    draw.rectangle([15, 18, 17, 28], fill=(110, 80, 50))
    draw.line([(15, 20), (17, 20)], fill=(170, 140, 90), width=1)
    save_item("iron_axe", img)

def gen_gold_sword():
    img = create_image([])
    draw = ImageDraw.Draw(img)
    draw.polygon([(14,2),(18,2),(18,20),(17,24),(15,24),(14,20)], fill=(200, 170, 60))
    draw.polygon([(14.5,4),(17.5,4),(17,18),(15,18)], fill=(255, 220, 120))
    draw.line([(15,4),(17,16)], fill=(255, 240, 170), width=1)
    draw.rectangle([10,20,22,22], fill=(190, 140, 50))
    draw.rectangle([14,22,18,30], fill=(120, 80, 30))
    save_item("gold_sword", img)

def gen_silver_armor():
    img = create_image([])
    draw = ImageDraw.Draw(img)
    draw.polygon([(10, 8), (22, 8), (24, 14), (22, 22), (10, 22), (8, 14)], fill=(170, 180, 200))
    draw.polygon([(11, 9), (21, 9), (23, 14), (21, 21), (11, 21), (9, 14)], fill=(210, 220, 235))
    draw.line([(16, 8), (16, 22)], fill=(150, 160, 180), width=2)
    save_item("silver_armor", img)

# RARE/QUEST ITEMS
def gen_ancient_core():
    img = create_image([])
    draw = ImageDraw.Draw(img)
    # Base facets
    draw.polygon([(16,4),(26,10),(26,20),(16,28),(6,20),(6,10)], fill=(110,90,170))
    draw.polygon([(16,6),(24,10),(24,20),(16,26),(8,20),(8,10)], fill=(160,130,220))
    # Inner glow radial
    draw.ellipse([11,11,21,21], fill=(220,170,255))
    draw.ellipse([13,13,19,19], fill=(240,200,255))
    # Center sparkle
    draw.ellipse([15,15,17,17], fill=(255,230,255))
    save_item("ancient_core", img)

def gen_ruins_key():
    img = create_image([])
    draw = ImageDraw.Draw(img)
    # Key shaft
    draw.rectangle([8, 12, 20, 16], fill=(180, 120, 60))
    # Key head (circle)
    draw.ellipse([6, 10, 14, 18], fill=(180, 120, 60))
    draw.ellipse([(7, 11), (13, 17)], fill=(200, 140, 80))
    # Key teeth
    draw.rectangle([20, 12, 22, 14], fill=(180, 120, 60))
    draw.rectangle([22, 14, 24, 16], fill=(180, 120, 60))
    draw.rectangle([24, 12, 26, 14], fill=(180, 120, 60))
    # Center hole
    draw.ellipse([9, 13, 11, 15], fill=(50, 30, 10))
    save_item("ruins_key", img)

def gen_ancient_coin():
    img = create_image([])
    draw = ImageDraw.Draw(img)
    # Coin
    draw.ellipse([6, 8, 26, 24], fill=(200, 180, 100))
    draw.ellipse([8, 10, 24, 22], fill=(220, 200, 120))
    # Engravings
    draw.polygon([(16, 10), (18, 14), (16, 18), (14, 14)], fill=(150, 130, 70))
    # Outer ring
    draw.ellipse([6, 8, 26, 24], outline=(150, 130, 70), width=2)
    # Texture marks
    draw.line([(10, 12), (12, 14)], fill=(150, 130, 70), width=1)
    draw.line([(20, 14), (22, 16)], fill=(150, 130, 70), width=1)
    save_item("ancient_coin", img)

def gen_ancient_relic():
    img = create_image([])
    draw = ImageDraw.Draw(img)
    # Relic shape
    draw.polygon([(16, 4), (24, 8), (26, 18), (24, 28), (8, 28), (6, 18), (8, 8)], fill=(140, 100, 80))
    # Carved details
    draw.line([(10, 12), (22, 12)], fill=(200, 160, 120), width=2)
    draw.line([(10, 18), (22, 18)], fill=(200, 160, 120), width=2)
    draw.line([(12, 24), (20, 24)], fill=(200, 160, 120), width=2)
    # Mystical glow
    draw.ellipse([(14, 14), (18, 18)], fill=(200, 150, 100))
    save_item("ancient_relic", img)

def gen_sandstone_amulet():
    img = create_image([])
    draw = ImageDraw.Draw(img)
    # Amulet circle
    draw.ellipse([8, 8, 24, 24], fill=(200, 170, 110))
    draw.ellipse([10, 10, 22, 22], fill=(220, 190, 130))
    # Symbol inside
    draw.line([(16, 12), (16, 20)], fill=(150, 120, 80), width=2)
    draw.line([(12, 16), (20, 16)], fill=(150, 120, 80), width=2)
    # Gems on sides
    draw.polygon([(8, 14), (10, 12), (10, 16)], fill=(255, 200, 100))
    draw.polygon([(24, 14), (22, 12), (22, 16)], fill=(255, 200, 100))
    # Chain
    draw.line([(14, 8), (14, 2)], fill=(180, 140, 80), width=2)
    draw.line([(18, 8), (18, 2)], fill=(180, 140, 80), width=2)
    save_item("sandstone_amulet", img)

def gen_cave_key():
    img = create_image([])
    draw = ImageDraw.Draw(img)
    # Key shaft (darker, rocky)
    draw.rectangle([8, 14, 22, 18], fill=(100, 80, 60))
    # Key head
    draw.ellipse([6, 12, 16, 20], fill=(100, 80, 60))
    draw.ellipse([7, 13, 15, 19], fill=(130, 110, 90))
    # Key teeth (rocky pattern)
    draw.rectangle([22, 14, 24, 16], fill=(100, 80, 60))
    draw.rectangle([24, 15, 26, 17], fill=(100, 80, 60))
    # Center hole
    draw.ellipse([10, 15, 12, 17], fill=(30, 20, 10))
    save_item("cave_key", img)

# TOOL/ARMOR ITEMS
def gen_boat():
    img = create_image([])
    draw = ImageDraw.Draw(img)
    # Boat hull
    draw.polygon([(8, 14), (24, 14), (26, 20), (6, 20)], fill=(120, 80, 40))
    draw.polygon([(8, 14), (24, 14), (22, 16), (10, 16)], fill=(150, 110, 60))
    # Deck
    draw.rectangle([(10, 12), (22, 14)], fill=(160, 120, 70))
    # Mast
    draw.line([(16, 6), (16, 12)], fill=(100, 70, 40), width=2)
    # Sail
    draw.polygon([(16, 8), (20, 12), (16, 12)], fill=(200, 200, 200))
    draw.line([(17, 8), (17, 12)], fill=(150, 150, 150), width=1)
    # Water
    draw.line([(6, 20), (26, 20)], fill=(80, 150, 200), width=2)
    draw.line([(6, 22), (26, 22)], fill=(60, 130, 180), width=1)
    save_item("boat", img)

def gen_steel_armor():
    img = create_image([])
    draw = ImageDraw.Draw(img)
    # Chest plate
    draw.polygon([(10, 8), (22, 8), (24, 14), (22, 22), (10, 22), (8, 14)], fill=(120, 140, 180))
    draw.polygon([(11, 9), (21, 9), (23, 14), (21, 21), (11, 21), (9, 14)], fill=(150, 170, 220))
    # Center line
    draw.line([(16, 8), (16, 22)], fill=(100, 120, 160), width=2)
    # Shoulder plates
    draw.ellipse([(5, 10), (11, 16)], fill=(150, 170, 220))
    draw.ellipse([(21, 10), (27, 16)], fill=(150, 170, 220))
    # Rivets
    for x, y in [(13, 12), (19, 12), (15, 16), (17, 18)]:
        draw.ellipse([x-1, y-1, x+1, y+1], fill=(100, 100, 100))
    save_item("steel_armor", img)

# Generate all items
print("Generating item textures...")
print("Food:")
gen_apple()
gen_berry()
gen_mushroom()
gen_fish()
gen_cactus_fruit()
gen_seaweed()
gen_hearty_stew()

print("Resources:")
gen_herb()
gen_wood()
gen_string()
gen_eastern_herb()
gen_northern_herb()
gen_desert_herb()

print("Healing:")
gen_minor_potion()
gen_stamina_tonic()

print("Weapons:")
gen_iron_sword()
gen_traveler_bow()
gen_fishing_rod()
gen_pickaxe()
gen_iron_ore()
gen_silver_ore()
gen_gold_ore()
gen_iron_axe()
gen_gold_sword()
gen_silver_armor()

print("Rare/Quest:")
gen_ancient_core()
gen_ruins_key()
gen_ancient_coin()
gen_ancient_relic()
gen_sandstone_amulet()
gen_cave_key()

print("Tools/Armor:")
gen_boat()
gen_steel_armor()

print("\n All 25 item textures generated!")

from __future__ import annotations

import random
import pygame
import os
import math

try:
    from PIL import Image
    import numpy as np
    HEIGHTMAP_AVAILABLE = True
except ImportError:
    HEIGHTMAP_AVAILABLE = False

import settings
from asset_helpers import TextureBank, ItemTextureBank


T_GRASS = 0
T_PATH = 1
T_WATER = 2
T_TREE = 3
T_ROCK = 4
T_FLOOR = 5
T_RUINS = 6
T_BRIDGE = 7
T_FENCE = 8
T_CLIFF = 9
T_WATERFALL = 10
T_DEEP_WATER = 11
T_SAND = 12
T_BUILDING = 13

# Map / journal POIs for 1920x1440 map: stable ids for discovery + save. Tile coords (not pixels).
# POIs placed realistically on procedural terrain with proper scaling (1.5x from original).
WORLD_POIS: list[dict[str, str | int]] = [
    # ===== CENTRAL VALLEY (main hub) =====
    {"id": "eldergrove", "name": "Eldergrove Settlement", "tx": 480, "ty": 480, "kind": "settlement"},
    {"id": "market_square", "name": "Market Square", "tx": 450, "ty": 510, "kind": "merchant"},
    {"id": "elder_rowan", "name": "Elder Rowan", "tx": 480, "ty": 450, "kind": "npc"},
    {"id": "town_shrine", "name": "Town Shrine", "tx": 510, "ty": 480, "kind": "secret"},
    
    # ===== NORTHERN FOREST REGION (around x:960, y:360) =====
    {"id": "frostwood_forest", "name": "Frostwood Forest", "tx": 960, "ty": 360, "kind": "wild"},
    {"id": "forest_lodge", "name": "Forest Lodge", "tx": 960, "ty": 330, "kind": "settlement"},
    {"id": "sacred_oak", "name": "Sacred Oak Grove", "tx": 990, "ty": 390, "kind": "secret"},
    {"id": "woodland_shrine", "name": "Woodland Shrine", "tx": 930, "ty": 360, "kind": "secret"},
    {"id": "hermit_cave", "name": "Hermit's Cave", "tx": 900, "ty": 300, "kind": "npc"},
    {"id": "forest_warden", "name": "Forest Warden's Post", "tx": 1020, "ty": 330, "kind": "npc"},
    
    # ===== WESTERN LAKE REGION (around x:288, y:720) =====
    {"id": "crystal_lake", "name": "Crystal Lake", "tx": 288, "ty": 720, "kind": "river"},
    {"id": "lakeside_village", "name": "Lakeside Village", "tx": 300, "ty": 750, "kind": "settlement"},
    {"id": "fishing_docks", "name": "Fishing Docks", "tx": 280, "ty": 720, "kind": "merchant"},
    {"id": "boatwright_shop", "name": "Boatwright's Workshop", "tx": 320, "ty": 750, "kind": "merchant"},
    {"id": "lake_shrine", "name": "Lake Shrine", "tx": 270, "ty": 690, "kind": "secret"},
    {"id": "fisher_old_man", "name": "Old Fisherman", "tx": 300, "ty": 780, "kind": "npc"},
    {"id": "waterfall", "name": "Cascade Falls", "tx": 240, "ty": 700, "kind": "river"},
    
    # ===== NORTHEASTERN MOUNTAINS (around x:1344, y:288) =====
    {"id": "cragpeak_summit", "name": "Cragpeak Summit", "tx": 1344, "ty": 288, "kind": "wild"},
    {"id": "mountain_village", "name": "Highpeak Village", "tx": 1320, "ty": 330, "kind": "settlement"},
    {"id": "mountain_shrine", "name": "Mountain Shrine", "tx": 1350, "ty": 270, "kind": "secret"},
    {"id": "crystal_cave", "name": "Crystal Caverns", "tx": 1380, "ty": 300, "kind": "dungeon"},
    {"id": "dragon_peak", "name": "Dragon's Peak", "tx": 1320, "ty": 240, "kind": "dungeon"},
    {"id": "stone_hall", "name": "Stone Hall Merchant", "tx": 1350, "ty": 330, "kind": "merchant"},
    {"id": "dwarven_mines", "name": "Dwarven Mines Entrance", "tx": 920, "ty": 160, "kind": "dungeon"},
    
    # ===== SOUTHEASTERN VOLCANO (around x:1440, y:936) =====
    {"id": "volcanic_plateau", "name": "Volcanic Plateau", "tx": 1440, "ty": 936, "kind": "wild"},
    {"id": "forge_town", "name": "Forge Town", "tx": 1440, "ty": 960, "kind": "settlement"},
    {"id": "volcano_smith", "name": "Master Smith's Forge", "tx": 1420, "ty": 940, "kind": "merchant"},
    {"id": "obsidian_temple", "name": "Obsidian Temple", "tx": 1450, "ty": 910, "kind": "ruins"},
    {"id": "lava_cave", "name": "Lava Cavern", "tx": 1410, "ty": 960, "kind": "dungeon"},
    {"id": "magma_spirit", "name": "Spirit of Magma", "tx": 1470, "ty": 930, "kind": "secret"},
    
    # ===== SOUTHWESTERN DESERT (around x:480, y:1080) =====
    {"id": "sand_dunes", "name": "Golden Dunes", "tx": 480, "ty": 1080, "kind": "wild"},
    {"id": "oasis_town", "name": "Desert Oasis Town", "tx": 510, "ty": 1050, "kind": "settlement"},
    {"id": "desert_caravan", "name": "Desert Caravan", "tx": 480, "ty": 1020, "kind": "merchant"},
    {"id": "sand_temple", "name": "Temple of Sand", "tx": 450, "ty": 1080, "kind": "ruins"},
    {"id": "scorpion_cave", "name": "Scorpion's Nest", "tx": 520, "ty": 1100, "kind": "dungeon"},
    {"id": "mirage_shrine", "name": "Mirage Shrine", "tx": 450, "ty": 1050, "kind": "secret"},
    
    # ===== SOUTHEASTERN SWAMP (around x:1152, y:1152) =====
    {"id": "murky_swamp", "name": "Murky Swamp", "tx": 1152, "ty": 1152, "kind": "wild"},
    {"id": "swamp_settlement", "name": "Swamp Settlement", "tx": 1180, "ty": 1180, "kind": "settlement"},
    {"id": "bog_dweller", "name": "Bog Dweller's Hut", "tx": 1150, "ty": 1200, "kind": "npc"},
    {"id": "sunken_ruin", "name": "Sunken Ruins", "tx": 1200, "ty": 1150, "kind": "ruins"},
    {"id": "marsh_cave", "name": "Marsh Cavern", "tx": 1120, "ty": 1160, "kind": "dungeon"},
    {"id": "wisp_grove", "name": "Wisp Grove", "tx": 1160, "ty": 1120, "kind": "secret"},
    
    # ===== CONNECTING PATHS & CAMPS =====
    {"id": "northpass_camp", "name": "North Pass Camp", "tx": 960, "ty": 600, "kind": "camp"},
    {"id": "eastroad_camp", "tx": 1200, "ty": 720, "name": "East Road Camp", "kind": "camp"},
    {"id": "westtrail_camp", "name": "West Trail Camp", "tx": 300, "ty": 600, "kind": "camp"},
    {"id": "southroad_outpost", "name": "South Road Outpost", "tx": 600, "ty": 1020, "kind": "camp"},
    
    # ===== SCATTERED LOCATIONS =====
    {"id": "moonlight_glade", "name": "Moonlight Glade", "tx": 600, "ty": 300, "kind": "secret"},
    {"id": "forgotten_crypt", "name": "Forgotten Crypt", "tx": 400, "ty": 800, "kind": "dungeon"},
    {"id": "ancient_gates", "name": "Ancient Gates", "tx": 800, "ty": 500, "kind": "ruins"},
    {"id": "tower_sentinel", "name": "Sentinel Tower", "tx": 1100, "ty": 400, "kind": "path"},
    {"id": "merchant_hub", "name": "Travelers' Hub", "tx": 700, "ty": 600, "kind": "merchant"},
    {"id": "hunter_post", "name": "Hunter's Post", "tx": 400, "ty": 400, "kind": "npc"},
    {"id": "alchemist_lab", "name": "Alchemist's Laboratory", "tx": 550, "ty": 450, "kind": "merchant"},
    {"id": "spirit_bridge", "name": "Spirit Bridge", "tx": 450, "ty": 850, "kind": "path"},
    {"id": "dragon_graveyard", "name": "Dragon Graveyard", "tx": 1250, "ty": 700, "kind": "ruins"},
    {"id": "wizard_spire", "name": "Wizard's Spire", "tx": 800, "ty": 300, "kind": "secret"},
]

POI_KIND_COLORS: dict[str, tuple[int, int, int]] = {
    "settlement": (255, 214, 120),
    "gate": (120, 220, 255),
    "wild": (100, 200, 120),
    "dungeon": (180, 120, 255),
    "ruins": (255, 160, 90),
    "camp": (200, 150, 100),
    "secret": (255, 120, 200),
    "path": (160, 150, 140),
    "river": (100, 170, 240),
    "merchant": (255, 230, 80),
    "npc": (150, 200, 255),
}


class World:
    def __init__(self, seed: int = 7) -> None:
        self.rng = random.Random(seed)
        self.w = settings.WORLD_WIDTH_TILES
        self.h = settings.WORLD_HEIGHT_TILES
        self.tiles = [[T_GRASS for _ in range(self.w)] for _ in range(self.h)]
        self.regions: dict[str, pygame.Rect] = {}
        self.landmarks: dict[str, tuple[int, int]] = {}
        self.gatherables: list[dict] = []
        self.weapon_spawns: list[dict] = []
        self.textures = TextureBank(settings.TILE_SIZE)
        self._generate()

    def _fill_rect(self, rect: pygame.Rect, tile: int) -> None:
        for y in range(max(0, rect.top), min(self.h, rect.bottom)):
            for x in range(max(0, rect.left), min(self.w, rect.right)):
                self.tiles[y][x] = tile

    def _noise_scatter(self, rect: pygame.Rect, tile: int, pct: float) -> None:
        for y in range(rect.top, rect.bottom):
            for x in range(rect.left, rect.right):
                if self.rng.random() < pct and 0 <= x < self.w and 0 <= y < self.h:
                    self.tiles[y][x] = tile

    def _noise_scatter_trees(self, rect: pygame.Rect, pct: float, min_spacing: int = 3) -> None:
        for y in range(max(0, rect.top), min(self.h, rect.bottom)):
            for x in range(max(0, rect.left), min(self.w, rect.right)):
                if self.tiles[y][x] != T_GRASS:
                    continue
                if self.rng.random() >= pct:
                    continue
                too_close = False
                for oy in range(-min_spacing, min_spacing + 1):
                    for ox in range(-min_spacing, min_spacing + 1):
                        ny, nx = y + oy, x + ox
                        if 0 <= nx < self.w and 0 <= ny < self.h and self.tiles[ny][nx] == T_TREE:
                            too_close = True
                            break
                    if too_close:
                        break
                if too_close:
                    continue
                self.tiles[y][x] = T_TREE

    def _generate(self) -> None:
        """Generate expanded BOTW-style world with massive POIs and diverse terrain"""
        # Define massive POI regions for epic exploration (scaled 2x)
        self.regions = {
            # Massive settlements
            "village": pygame.Rect(60, 60, 240, 180),  # Eldervale - enormous village
            "north_village": pygame.Rect(500, 40, 200, 150),  # Frosthold - huge
            "east_village": pygame.Rect(1000, 400, 220, 160),  # Dawnbreak - massive
            "south_village": pygame.Rect(300, 760, 190, 140),  # New southern village
            
            # Massive caves and dungeons
            "cave": pygame.Rect(900, 120, 120, 90),
            "dwarven_mines": pygame.Rect(900, 140, 40, 30),
            "south_cave": pygame.Rect(240, 700, 130, 100),
            "west_cave": pygame.Rect(40, 500, 100, 120),
            "north_cave": pygame.Rect(600, 20, 110, 80),
            "east_cave": pygame.Rect(1160, 600, 100, 90),
            
            # Massive ruins and temples
            "ruins": pygame.Rect(800, 600, 150, 130),
            "north_ruins": pygame.Rect(400, 200, 140, 110),
            "west_ruins": pygame.Rect(20, 700, 120, 100),
            
            # Massive camps and outposts
            "remote_camp": pygame.Rect(600, 600, 80, 70),
            "mountain_camp": pygame.Rect(700, 300, 70, 60),
            "forest_camp": pygame.Rect(200, 300, 60, 50),
            
            # Forests and orchards for spawning
            "forest": pygame.Rect(300, 200, 240, 220),  # Northern/western forest
            "orchard": pygame.Rect(120, 140, 160, 100),  # Sun Orchard area
            
            # Massive hidden areas
            "hidden_glade": pygame.Rect(1000, 100, 70, 70),
            "mountain_pass": pygame.Rect(700, 240, 90, 80),
            "sacred_grove": pygame.Rect(440, 400, 80, 70),
            "ancient_temple": pygame.Rect(90, 240, 90, 80),
        }
        
        # Disable heightmap - use procedural generation only
        # hm_path = os.path.join(settings.ASSETS_DIR, "heightmap.png")
        # if HEIGHTMAP_AVAILABLE and os.path.exists(hm_path):
        #     try:
        #         self._generate_from_heightmap(hm_path)
        #     except Exception as e:
        #         # Fall back to procedural on error
        #         self._generate_natural_terrain()
        #         self._generate_poi_structures()
        #         self._generate_roads()
        #         self._generate_docks()
        #         self._generate_grassland_features()
        # else:
        #     # Procedural generation
        
        # Always use procedural generation
        self._generate_natural_terrain()
        self._generate_poi_structures()
        self._generate_roads()
        self._generate_docks()
        self._generate_grassland_features()
        
        # Clear paths of obstacles
        self._clear_paths()
        
        # Generate landmarks and spawn points
        self._generate_landmarks()
        self._spawn_points()

    def _generate_from_heightmap(self, hm_path: str) -> None:
        """Load and apply a heightmap-based terrain (1920x1440 PNG grayscale)."""
        img = Image.open(hm_path).convert('L')
        img = img.resize((self.w, self.h), Image.LANCZOS)
        hmap = np.array(img, dtype=np.float32) / 255.0
        
        # Threshold-based tile assignment from elevation - balanced for walkability
        for y in range(self.h):
            for x in range(self.w):
                elev = hmap[y, x]
                
                # Deep water (lowest)
                if elev < 0.2:
                    self.tiles[y][x] = T_DEEP_WATER
                # Water
                elif elev < 0.28:
                    self.tiles[y][x] = T_WATER
                # Sand beaches
                elif elev < 0.35:
                    self.tiles[y][x] = T_SAND
                # Grassland (majority of terrain)
                elif elev < 0.6:
                    self.tiles[y][x] = T_GRASS
                # Forested areas with trees (still walkable)
                elif elev < 0.72:
                    if self.rng.random() < 0.5:
                        self.tiles[y][x] = T_TREE
                    else:
                        self.tiles[y][x] = T_GRASS
                # Rocky highland terrain
                elif elev < 0.82:
                    if self.rng.random() < 0.6:
                        self.tiles[y][x] = T_ROCK
                    else:
                        self.tiles[y][x] = T_GRASS
                # High peaks and mountains - only these are impassable
                elif elev < 0.92:
                    self.tiles[y][x] = T_CLIFF
                # Snow peaks (highest)
                else:
                    self.tiles[y][x] = T_CLIFF
        
        # Carve out rivers from low elevation areas
        for y in range(1, self.h - 1):
            for x in range(1, self.w - 1):
                if hmap[y, x] < 0.28:
                    neighbors_higher = sum(1 for dy in [-1, 0, 1] for dx in [-1, 0, 1]
                                          if (dy != 0 or dx != 0) and hmap[y + dy, x + dx] > 0.35)
                    if neighbors_higher >= 4:
                        self.tiles[y][x] = T_WATER if self.rng.random() < 0.7 else T_DEEP_WATER
        
        # Add terrain features on top (POI structures, roads, docks)
        self._generate_poi_structures()
        self._generate_roads()
        self._generate_docks()
        self._generate_grassland_features()

    def _generate_natural_terrain(self) -> None:
        """Generate diverse BOTW-style natural terrain for massive world (scaled 2x)"""
        # Multiple river systems (scaled 2x)
        self._fill_rect(pygame.Rect(0, 400, 1280, 24), T_WATER)  # Central river
        self._fill_rect(pygame.Rect(600, 200, 20, 240), T_WATER)  # Northern tributary
        self._fill_rect(pygame.Rect(300, 600, 16, 200), T_WATER)  # Southern tributary
        self._fill_rect(pygame.Rect(1000, 100, 12, 160), T_WATER)  # Eastern stream
        self._fill_rect(pygame.Rect(200, 360, 16, 180), T_WATER)  # Western river branch
        self._fill_rect(pygame.Rect(200, 540, 120, 16), T_WATER)
        self._fill_rect(pygame.Rect(320, 520, 16, 80), T_WATER)
        self._fill_rect(pygame.Rect(470, 260, 16, 220), T_WATER)  # Central backwater
        self._fill_rect(pygame.Rect(470, 460, 100, 16), T_WATER)
        self._fill_rect(pygame.Rect(760, 120, 14, 170), T_WATER)  # Midriver feeder
        self._fill_rect(pygame.Rect(730, 264, 90, 16), T_WATER)
        self._noise_scatter(pygame.Rect(140, 380, 90, 90), T_WATER, 0.18)
        self._noise_scatter(pygame.Rect(520, 240, 120, 120), T_WATER, 0.16)
        self._noise_scatter(pygame.Rect(640, 100, 80, 160), T_WATER, 0.12)
        self._noise_scatter(pygame.Rect(980, 660, 120, 90), T_WATER, 0.20)
        
        # Massive lakes and ponds (scaled 2x)
        self._fill_rect(pygame.Rect(240, 160, 70, 50), T_DEEP_WATER)  # Northern lake
        self._fill_rect(pygame.Rect(900, 240, 56, 40), T_DEEP_WATER)  # Eastern lake
        self._fill_rect(pygame.Rect(160, 600, 50, 36), T_DEEP_WATER)  # Southern pond
        self._fill_rect(pygame.Rect(1100, 700, 60, 44), T_DEEP_WATER)  # Southeast lake
        self._fill_rect(pygame.Rect(400, 800, 40, 30), T_DEEP_WATER)  # Southwest pond
        self._fill_rect(pygame.Rect(980, 680, 80, 60), T_DEEP_WATER)  # New eastern pond
        self._fill_rect(pygame.Rect(240, 520, 60, 44), T_DEEP_WATER)  # Hidden estuary lake
        
        # Spectacular waterfalls (scaled 2x)
        self._fill_rect(pygame.Rect(596, 200, 8, 200), T_WATERFALL)  # Northern falls
        self._fill_rect(pygame.Rect(296, 160, 8, 70), T_WATERFALL)  # Lake falls
        self._fill_rect(pygame.Rect(956, 240, 8, 90), T_WATERFALL)  # Eastern falls
        self._fill_rect(pygame.Rect(1140, 100, 8, 160), T_WATERFALL)  # Mountain falls
        self._fill_rect(pygame.Rect(220, 520, 8, 44), T_WATERFALL)  # Hidden estuary spill
        self._fill_rect(pygame.Rect(760, 260, 8, 30), T_WATERFALL)  # Midriver cascade
        
        # Generate diverse terrain features (scaled 3x)
        self._generate_mountains()
        self._generate_forests()
        self._generate_canyons()
        self._generate_deserts()
        self._generate_swamps()
        self._generate_volcanoes()
        self._generate_beaches()

    def _generate_mountains(self) -> None:
        """Generate mountain ranges with cliffs (scaled 2x)"""
        # Northern mountains
        self._fill_rect(pygame.Rect(840, 0, 240, 120), T_CLIFF)
        self._fill_rect(pygame.Rect(960, 120, 120, 60), T_CLIFF)
        
        # Western mountains
        self._fill_rect(pygame.Rect(0, 240, 120, 180), T_CLIFF)
        self._fill_rect(pygame.Rect(120, 300, 90, 120), T_CLIFF)
        
        # Eastern mountains
        self._fill_rect(pygame.Rect(1160, 360, 120, 240), T_CLIFF)
        self._fill_rect(pygame.Rect(1200, 480, 60, 120), T_CLIFF)
        
        # Southern peaks
        self._fill_rect(pygame.Rect(600, 840, 180, 120), T_CLIFF)
        self._fill_rect(pygame.Rect(720, 780, 60, 60), T_CLIFF)

    def _generate_forests(self) -> None:
        """Generate multiple forests with varied tree density (scaled 3x)"""
        # Dense northern forest
        self._noise_scatter_trees(pygame.Rect(180, 30, 360, 210), 0.18)
        
        # Sparse eastern forest
        self._noise_scatter_trees(pygame.Rect(1140, 180, 240, 180), 0.10)
        
        # Mixed central forest
        self._noise_scatter_trees(pygame.Rect(450, 150, 300, 240), 0.14)
        
        # Southern woodland
        self._noise_scatter_trees(pygame.Rect(150, 540, 270, 180), 0.12)
        
        # Small groves
        self._noise_scatter_trees(pygame.Rect(900, 600, 150, 120), 0.08)
        self._noise_scatter_trees(pygame.Rect(540, 360, 120, 90), 0.10)

    def _generate_canyons(self) -> None:
        """Generate canyons and rocky valleys (scaled 3x)"""
        # Deep canyon
        self._fill_rect(pygame.Rect(480, 480, 18, 120), T_CLIFF)
        self._fill_rect(pygame.Rect(420, 540, 120, 18), T_CLIFF)
        
        # Rocky valley
        self._noise_scatter(pygame.Rect(240, 720, 180, 120), T_ROCK, 0.15)
        
        # Plateau edges
        self._fill_rect(pygame.Rect(900, 480, 150, 12), T_CLIFF)

    def _generate_beaches(self) -> None:
        """Generate sandy beaches around water (scaled 2x)"""
        self._fill_rect(pygame.Rect(345, 315, 135, 12), T_SAND)
        self._fill_rect(pygame.Rect(1166, 420, 114, 12), T_SAND)
        self._fill_rect(pygame.Rect(225, 930, 105, 12), T_SAND)
        self._fill_rect(pygame.Rect(1160, 836, 120, 12), T_SAND)
        self._fill_rect(pygame.Rect(585, 750, 90, 12), T_SAND)

    def _fill_rect_if_grass(self, rect: pygame.Rect, tile: int) -> None:
        for y in range(max(0, rect.top), min(self.h, rect.bottom)):
            for x in range(max(0, rect.left), min(self.w, rect.right)):
                if self.tiles[y][x] == T_GRASS:
                    self.tiles[y][x] = tile

    def _noise_scatter_grass(self, rect: pygame.Rect, tile: int, pct: float) -> None:
        for y in range(max(0, rect.top), min(self.h, rect.bottom)):
            for x in range(max(0, rect.left), min(self.w, rect.right)):
                if self.tiles[y][x] == T_GRASS and self.rng.random() < pct:
                    self.tiles[y][x] = tile

    def _generate_grassland_features(self) -> None:
        """Fill empty grassland areas with scenic features and small structures."""
        meadow_areas = [
            pygame.Rect(160, 420, 200, 180),
            pygame.Rect(520, 260, 220, 140),
            pygame.Rect(760, 560, 220, 180),
            pygame.Rect(900, 80, 150, 120),
            pygame.Rect(60, 520, 180, 170),
            pygame.Rect(430, 520, 160, 140),
            pygame.Rect(1040, 640, 140, 120),
        ]
        for area in meadow_areas:
            self._noise_scatter_trees(area, 0.10, min_spacing=4)
            self._noise_scatter_grass(area, T_ROCK, 0.09)
            self._noise_scatter_grass(area, T_SAND, 0.06)

        small_structures = [
            (pygame.Rect(680, 180, 10, 10), pygame.Rect(686, 180, 1, 6), pygame.Rect(686, 180, 6, 1)),
            (pygame.Rect(730, 580, 10, 10), pygame.Rect(738, 580, 1, 6), pygame.Rect(738, 580, 6, 1)),
            (pygame.Rect(140, 430, 10, 8), pygame.Rect(146, 430, 1, 5), pygame.Rect(146, 430, 5, 1)),
            (pygame.Rect(456, 532, 12, 12), pygame.Rect(460, 532, 1, 6), pygame.Rect(460, 538, 6, 1)),
            (pygame.Rect(1040, 650, 12, 10), pygame.Rect(1044, 650, 1, 6), pygame.Rect(1044, 650, 6, 1)),
        ]
        for structure, path_a, path_b in small_structures:
            self._fill_rect_if_grass(structure, T_FLOOR)
            self._fill_rect_if_grass(path_a, T_PATH)
            self._fill_rect_if_grass(path_b, T_PATH)

    def _generate_deserts(self) -> None:
        """Generate desert regions with sand dunes (scaled 2x)"""
        # Eastern desert
        self._noise_scatter(pygame.Rect(1040, 660, 240, 180), T_SAND, 0.4)
        # Southern desert
        self._noise_scatter(pygame.Rect(900, 760, 300, 150), T_SAND, 0.35)
        # Add some rocky outcrops in deserts
        self._noise_scatter(pygame.Rect(1040, 660, 240, 180), T_ROCK, 0.1)
        self._noise_scatter(pygame.Rect(900, 760, 300, 150), T_ROCK, 0.08)

    def _generate_swamps(self) -> None:
        """Generate swampy marshlands (scaled 2x)"""
        # Southwestern swamp
        self._noise_scatter(pygame.Rect(150, 720, 210, 180), T_WATER, 0.25)
        self._noise_scatter(pygame.Rect(150, 720, 210, 180), T_DEEP_WATER, 0.15)
        # Add swamp vegetation (represented as sparse swamp trees)
        self._noise_scatter_trees(pygame.Rect(150, 720, 210, 180), 0.18)

    def _generate_volcanoes(self) -> None:
        """Generate volcanic regions with lava and ash (scaled 2x)"""
        # Volcanic mountain in southeast
        self._fill_rect(pygame.Rect(1080, 760, 120, 105), T_CLIFF)
        # Add lava flows (represented as special water tiles near volcano)
        self._fill_rect(pygame.Rect(1070, 825, 75, 9), T_WATER)
        self._fill_rect(pygame.Rect(1115, 834, 45, 6), T_WATER)

    def _generate_poi_structures(self) -> None:
        """Generate structures for larger POIs (scaled 3x)"""
        # Eldervale village - much bigger
        # Outer walls
        self._fill_rect(pygame.Rect(60, 60, 240, 9), T_FENCE)   # Top wall
        self._fill_rect(pygame.Rect(60, 231, 240, 9), T_FENCE)   # Bottom wall
        self._fill_rect(pygame.Rect(60, 60, 9, 180), T_FENCE)   # Left wall
        self._fill_rect(pygame.Rect(291, 60, 9, 180), T_FENCE)   # Right wall
        # Village exits
        self._fill_rect(pygame.Rect(60, 135, 9, 30), T_PATH)    # West gate opening
        self._fill_rect(pygame.Rect(291, 135, 9, 30), T_PATH)   # East gate opening
        self._fill_rect(pygame.Rect(80, 231, 24, 9), T_PATH)    # South gate opening
        
        # Inner buildings and structures
        self._fill_rect(pygame.Rect(90, 90, 36, 24), T_FLOOR)   # House 1
        self._fill_rect(pygame.Rect(150, 90, 36, 24), T_FLOOR)   # House 2
        self._fill_rect(pygame.Rect(210, 90, 36, 24), T_FLOOR)   # House 3
        self._fill_rect(pygame.Rect(90, 135, 36, 24), T_FLOOR)   # House 4
        self._fill_rect(pygame.Rect(150, 135, 36, 24), T_FLOOR)   # House 5
        self._fill_rect(pygame.Rect(210, 135, 36, 24), T_FLOOR)   # House 6
        self._fill_rect(pygame.Rect(90, 180, 36, 24), T_FLOOR)   # House 7
        self._fill_rect(pygame.Rect(150, 180, 36, 24), T_FLOOR)   # House 8
        
        # Central square and paths
        self._fill_rect(pygame.Rect(135, 105, 90, 12), T_PATH)    # Main path
        self._fill_rect(pygame.Rect(165, 75, 12, 120), T_PATH)    # Vertical path
        self._fill_rect(pygame.Rect(270, 135, 12, 30), T_PATH)    # Gate path
        
        # North village - Frosthold
        self._fill_rect(pygame.Rect(540, 30, 210, 9), T_FENCE)  # Top wall
        self._fill_rect(pygame.Rect(540, 171, 210, 9), T_FENCE)  # Bottom wall
        self._fill_rect(pygame.Rect(540, 30, 9, 150), T_FENCE)  # Left wall
        self._fill_rect(pygame.Rect(741, 30, 9, 150), T_FENCE)  # Right wall
        
        # Buildings
        self._fill_rect(pygame.Rect(570, 60, 30, 21), T_FLOOR)  # House 1
        self._fill_rect(pygame.Rect(630, 60, 30, 21), T_FLOOR)  # House 2
        self._fill_rect(pygame.Rect(690, 60, 30, 21), T_FLOOR)  # House 3
        self._fill_rect(pygame.Rect(570, 105, 30, 21), T_FLOOR)  # House 4
        self._fill_rect(pygame.Rect(630, 105, 30, 21), T_FLOOR)  # House 5
        self._fill_rect(pygame.Rect(690, 105, 30, 21), T_FLOOR)  # House 6
        
        # Paths
        self._fill_rect(pygame.Rect(585, 75, 105, 9), T_PATH)   # Main path
        self._fill_rect(pygame.Rect(645, 45, 9, 105), T_PATH)   # Vertical path
        
        # East village - Dawnbreak
        self._fill_rect(pygame.Rect(1050, 450, 225, 9), T_FENCE) # Top wall
        self._fill_rect(pygame.Rect(1050, 651, 225, 9), T_FENCE) # Bottom wall
        self._fill_rect(pygame.Rect(1050, 450, 9, 210), T_FENCE) # Left wall
        self._fill_rect(pygame.Rect(1266, 450, 9, 210), T_FENCE) # Right wall
        
        # Buildings
        self._fill_rect(pygame.Rect(1080, 480, 30, 21), T_FLOOR) # House 1
        self._fill_rect(pygame.Rect(1140, 480, 30, 21), T_FLOOR) # House 2
        self._fill_rect(pygame.Rect(1200, 480, 30, 21), T_FLOOR) # House 3
        self._fill_rect(pygame.Rect(1080, 525, 30, 21), T_FLOOR) # House 4
        self._fill_rect(pygame.Rect(1140, 525, 30, 21), T_FLOOR) # House 5
        self._fill_rect(pygame.Rect(1200, 525, 30, 21), T_FLOOR) # House 6

        # Dwarven Mines entrance area
        self._fill_rect(pygame.Rect(910, 150, 20, 14), T_ROCK)
        self._fill_rect(pygame.Rect(914, 154, 12, 6), T_FLOOR)
        self._fill_rect(pygame.Rect(914, 160, 12, 4), T_PATH)
        self._fill_rect(pygame.Rect(900, 168, 20, 9), T_PATH)

        # Paths
        self._fill_rect(pygame.Rect(1095, 495, 105, 9), T_PATH)   # Main path
        self._fill_rect(pygame.Rect(1155, 465, 9, 120), T_PATH)   # Vertical path

    def _generate_roads(self) -> None:
        """Generate extensive road network connecting massive settlements (scaled 2x)"""
        # Main highway from Eldervale through the world
        self._fill_rect(pygame.Rect(330, 195, 600, 24), T_PATH)    # From village to north
        self._fill_rect(pygame.Rect(900, 195, 24, 180), T_PATH)     # North turn
        self._fill_rect(pygame.Rect(900, 351, 330, 24), T_PATH)   # East to Dawnbreak
        self._fill_rect(pygame.Rect(0, 135, 60, 24), T_PATH)      # West exit road from Eldervale
        self._fill_rect(pygame.Rect(60, 144, 24, 24), T_PATH)     # West gate approach
        self._fill_rect(pygame.Rect(291, 159, 24, 24), T_PATH)    # East gate internal connector
        self._fill_rect(pygame.Rect(80, 231, 180, 24), T_PATH)    # South gate connection road
        self._fill_rect(pygame.Rect(1230, 351, 24, 300), T_PATH)   # South to southern village
        self._fill_rect(pygame.Rect(600, 840, 680, 24), T_PATH)   # Southern route
        self._fill_rect(pygame.Rect(60, 376, 240, 16), T_PATH)    # Scenic north river bank
        self._fill_rect(pygame.Rect(280, 376, 420, 16), T_PATH)   # Central riverbank trail
        self._fill_rect(pygame.Rect(700, 360, 16, 180), T_PATH)   # River road connector

        # Branch roads to various POIs
        self._fill_rect(pygame.Rect(330, 207, 24, 150), T_PATH)     # South from Eldervale
        self._fill_rect(pygame.Rect(330, 345, 180, 24), T_PATH)    # To western ruins
        self._fill_rect(pygame.Rect(330, 375, 24, 40), T_PATH)     # Dock access runway
        self._fill_rect(pygame.Rect(444, 572, 12, 26), T_PATH)     # Access to northern dock
        self._fill_rect(pygame.Rect(1180, 624, 12, 32), T_PATH)    # Access to eastern dock
        self._fill_rect(pygame.Rect(296, 628, 18, 10), T_PATH)     # Access to southern dock
        self._fill_rect(pygame.Rect(580, 712, 12, 24), T_PATH)     # Access to southern lake dock

    def _generate_docks(self) -> None:
        """Generate river docks and water-side content along river banks."""
        dock_areas = [
            pygame.Rect(330, 412, 14, 4),
            pygame.Rect(444, 598, 12, 4),
            pygame.Rect(1180, 606, 12, 4),
            pygame.Rect(296, 612, 14, 4),
            pygame.Rect(1000, 116, 12, 4),
            pygame.Rect(580, 712, 12, 4),
        ]
        dock_walkways = [
            pygame.Rect(330, 392, 14, 20),
            pygame.Rect(444, 578, 12, 24),
            pygame.Rect(1180, 586, 12, 24),
            pygame.Rect(296, 596, 14, 18),
            pygame.Rect(1000, 96, 12, 22),
            pygame.Rect(580, 692, 12, 24),
        ]
        for walk in dock_walkways:
            self._fill_rect(walk, T_FLOOR)
        for rect in dock_areas:
            self._fill_rect(rect, T_FLOOR)
            self._fill_rect_if_grass(pygame.Rect(rect.left, rect.top - 1, rect.width, 1), T_PATH)
            self._fill_rect_if_grass(pygame.Rect(rect.left - 1, rect.top, 1, rect.height), T_FENCE)
            self._fill_rect_if_grass(pygame.Rect(rect.right, rect.top, 1, rect.height), T_FENCE)
            self._fill_rect_if_grass(pygame.Rect(rect.left, rect.bottom, rect.width, 1), T_FENCE)
            self._fill_rect_if_grass(pygame.Rect(rect.left - 2, rect.top - 2, rect.width + 4, rect.height + 4), T_SAND)

    def _clear_paths(self) -> None:
        """Clear obstacles from paths"""
        for y in range(self.h):
            for x in range(self.w):
                if self.tiles[y][x] in (T_PATH, T_BRIDGE):
                    for oy in (-1, 0, 1):
                        for ox in (-1, 0, 1):
                            tx, ty = x + ox, y + oy
                            if 0 <= tx < self.w and 0 <= ty < self.h:
                                if self.tiles[ty][tx] in (T_TREE, T_ROCK, T_CLIFF):
                                    self.tiles[ty][tx] = T_GRASS

    def _generate_landmarks(self) -> None:
        """Generate landmark positions for massive world (scaled 2x)"""
        self.landmarks = {
            "Eldervale Village": (270, 210),
            "Frosthold Village": (900, 165),
            "Dawnbreak Village": (912, 420),
            "Harbortown Village": (1180, 540),
            "Stonehollow Cave": (544, 104),
            "Deepshadow Cave": (312, 714),
            "Whispering Depths": (90, 468),
            "Northpeak Cave": (600, 90),
            "Eastspire Cave": (1160, 600),
            "Ashen Ruins": (544, 376),
            "Northspire Ruins": (705, 381),
            "Westwatch Ruins": (60, 720),
            "Road Camp": (344, 392),
            "Mountain Outpost": (1116, 420),
            "Forest Haven": (345, 486),
            "Hidden Glade": (1000, 100),
            "Highpeak Pass": (700, 240),
            "Sacred Grove": (440, 400),
            "Ancient Temple": (90, 240),
            "Volcanic Summit": (1100, 780),
            "Crystal Lake": (405, 276),
            "Mirror Lake": (1160, 390),
            "Swamp of Whispers": (210, 820),
            "Eastern Desert": (1040, 700),
            "Southern Wastes": (900, 820),
        }

    def _spawn_points(self) -> None:
        self.gatherables = []
        
        for _ in range(252):
            region = self.rng.choice(["village", "north_village", "east_village", "remote_camp"])
            self.gatherables.append({"tile": self._rand_point(self.regions[region]), "item": "apple", "respawn": 0.0})
        
        
        for _ in range(312):
            
            x = self.rng.randint(0, self.w - 1)
            y = self.rng.randint(0, self.h - 1)
            if self.tiles[y][x] == T_GRASS:  # Only on grass tiles
                self.gatherables.append({"tile": (x, y), "item": "berry", "respawn": 0.0})
        
        
        for _ in range(168):
            region = self.rng.choice(["cave", "south_cave", "west_cave"])
            self.gatherables.append({"tile": self._rand_point(self.regions[region]), "item": "mushroom", "respawn": 0.0})
        
        
        for _ in range(126):
            region = self.rng.choice(["village", "north_village", "east_village"])
            self.gatherables.append({"tile": self._rand_point(self.regions[region]), "item": "herb", "respawn": 0.0})
        
        # Fish near water (scaled 3x)
        for _ in range(114):
            region = self.rng.choice(["village", "north_village", "east_village"])
            self.gatherables.append({"tile": self._rand_point(self.regions[region]), "item": "fish", "respawn": 0.0})
        
        # Boats at river docks (scaled 3x)
        dock_areas = [
            pygame.Rect(330, 412, 14, 4),
            pygame.Rect(444, 598, 12, 4),
            pygame.Rect(1180, 606, 12, 4),
            pygame.Rect(296, 612, 14, 4),
            pygame.Rect(1000, 116, 12, 4),
            pygame.Rect(580, 712, 12, 4),
        ]
        for _ in range(24):
            region = self.rng.choice(dock_areas)
            self.gatherables.append({"tile": self._rand_point(region), "item": "boat", "respawn": 0.0})

        # More mushrooms in southern areas (scaled 3x)
        for _ in range(96):
            region = self.rng.choice(["south_cave", "west_cave"])
            self.gatherables.append({"tile": self._rand_point(self.regions[region]), "item": "mushroom", "respawn": 0.0})

        # Ores in cave systems
        for _ in range(24):
            region = self.rng.choice(["cave", "south_cave", "west_cave"])
            self.gatherables.append({"tile": self._rand_point(self.regions[region]), "item": "iron_ore", "respawn": 0.0})
        for _ in range(18):
            region = self.rng.choice(["cave", "south_cave"])
            self.gatherables.append({"tile": self._rand_point(self.regions[region]), "item": "silver_ore", "respawn": 0.0})
        for _ in range(10):
            region = self.rng.choice(["south_cave", "west_cave"])
            self.gatherables.append({"tile": self._rand_point(self.regions[region]), "item": "gold_ore", "respawn": 0.0})

        weapon_candidates = [
            ("iron_sword", self.regions["ruins"]),
            ("traveler_bow", self.regions["village"]),  # Changed from forest to village
            ("iron_sword", self.regions["cave"]),
            ("traveler_bow", self.regions["hidden_glade"]),
            ("iron_sword", self.regions["mountain_pass"]),
            ("traveler_bow", self.regions["east_village"]),
        ]
        self.weapon_spawns = []
        for wid, rect in weapon_candidates:
            self.weapon_spawns.append({"tile": self._rand_point(rect), "item": wid, "taken": False})

    def _rand_point(self, rect: pygame.Rect) -> tuple[int, int]:
        for _ in range(1000):
            x = self.rng.randint(rect.left, rect.right - 1)
            y = self.rng.randint(rect.top, rect.bottom - 1)
            if self.tiles[y][x] in (T_GRASS, T_FLOOR, T_RUINS):
                return x, y
        return rect.centerx, rect.centery

    def tile_at_px(self, px: float, py: float) -> int:
        tx, ty = int(px // settings.TILE_SIZE), int(py // settings.TILE_SIZE)
        if tx < 0 or ty < 0 or tx >= self.w or ty >= self.h:
            return T_ROCK
        return self.tiles[ty][tx]

    def collides(self, rect: pygame.Rect, allow_boat: bool = False) -> bool:
        if rect.left < 0 or rect.top < 0:
            return True
        if rect.right > self.w * settings.TILE_SIZE or rect.bottom > self.h * settings.TILE_SIZE:
            return True
        ts = settings.TILE_SIZE
        x0, y0 = max(0, rect.left // ts), max(0, rect.top // ts)
        x1, y1 = min(self.w - 1, rect.right // ts), min(self.h - 1, rect.bottom // ts)
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                if x < 0 or y < 0 or x >= self.w or y >= self.h:
                    continue
                t = self.tiles[y][x]
                # Block only walls and water (everything else is walkable)
                if t in (T_WATER, T_DEEP_WATER, T_WATERFALL, T_CLIFF, T_FENCE, T_BUILDING):
                    return True
        return False

    def region_name_for_px(self, px: float, py: float) -> str:
        tx, ty = int(px // settings.TILE_SIZE), int(py // settings.TILE_SIZE)
        for name, rect in self.regions.items():
            if rect.collidepoint(tx, ty):
                return name
        return "wilds"

    def update(self, dt: float) -> None:
        for g in self.gatherables:
            if g["respawn"] > 0:
                g["respawn"] = max(0.0, g["respawn"] - dt)

    def try_collect_near(self, px: float, py: float, has_pickaxe: bool = False) -> str | None:
        ts = settings.TILE_SIZE
        p = pygame.Vector2(px // ts, py // ts)
        for g in self.gatherables:
            if g["respawn"] > 0:
                continue
            if g["item"] in ("iron_ore", "silver_ore", "gold_ore") and not has_pickaxe:
                continue
            gp = pygame.Vector2(g["tile"][0], g["tile"][1])
            if gp.distance_to(p) <= 1.4:
                g["respawn"] = 90.0
                return g["item"]
        for w in self.weapon_spawns:
            if w["taken"]:
                continue
            wp = pygame.Vector2(w["tile"][0], w["tile"][1])
            if wp.distance_to(p) <= 1.1:
                w["taken"] = True
                return w["item"]
        return None

    def draw(self, surf: pygame.Surface, cam_x: float, cam_y: float, day_light: float, anim_time: float = 0.0, item_textures: ItemTextureBank | None = None) -> None:
        ts = settings.TILE_SIZE
        left = max(0, int(cam_x // ts))
        top = max(0, int(cam_y // ts))
        right = min(self.w, left + surf.get_width() // ts + 3)
        bottom = min(self.h, top + surf.get_height() // ts + 3)
        
        # Sort tiles by depth for pseudo-3D effect (back to front)
        tiles_to_draw = []
        for y in range(top, bottom):
            for x in range(left, right):
                tile_surf = self.textures.tile(self.tiles[y][x], anim_time)
                
                # Lighting based on time of day
                lit = 0.55 + day_light * 0.55
                
                # Add height-based depth shading (pseudo-3D)
                height_factor = 0
                if self.tiles[y][x] in (T_CLIFF, T_ROCK):
                    height_factor = 0.3  # Cliffs appear higher
                elif self.tiles[y][x] == T_TREE:
                    height_factor = 0.2  # Trees have height
                elif self.tiles[y][x] in (T_FENCE, T_BUILDING):
                    height_factor = 0.4  # Structures are tallest
                
                shade = max(0, min(255, int(255 * lit * (0.8 + height_factor * 0.4))))
                
                draw_surf = tile_surf.copy()
                draw_surf.fill((shade, shade, shade), special_flags=pygame.BLEND_MULT)
                
                # Add subtle isometric shadow effect
                if height_factor > 0:
                    shadow = pygame.Surface((ts, ts), pygame.SRCALPHA)
                    pygame.draw.polygon(shadow, (0, 0, 0, 30), [(0, ts), (ts, ts), (ts - 4, ts - 4), (4, ts - 4)])
                    draw_surf.blit(shadow, (0, 0))
                
                tiles_to_draw.append((y, x, draw_surf, x * ts - cam_x, y * ts - cam_y))
        
        # Sort by Y coordinate for depth (pseudo-3D layering)
        tiles_to_draw.sort(key=lambda t: t[0])
        
        for _, _, tile_surf, dx, dy in tiles_to_draw:
            surf.blit(tile_surf, (dx, dy))

        for g in self.gatherables:
            if g["respawn"] > 0:
                continue
            x, y = g["tile"]
            offset_x = x * ts - cam_x
            offset_y = y * ts - cam_y
            bob = int((anim_time * 4 + x * 0.2 + y * 0.3) % 2)
            item_tex = item_textures.get_item_or_placeholder(g["item"], ts) if item_textures else None
            if item_tex is not None:
                icon_w, icon_h = item_tex.get_size()
                icon_x = int(offset_x + (ts - icon_w) / 2)
                icon_y = int(offset_y + (ts - icon_h) / 2 - 3 - bob)
                glow_alpha = 60 + int(40 * (0.5 + 0.5 * math.sin(anim_time * 4 + x + y)))
                glow = pygame.Surface((icon_w + 10, icon_h + 10), pygame.SRCALPHA)
                pygame.draw.ellipse(glow, (180, 220, 220, glow_alpha), glow.get_rect())
                surf.blit(glow, (icon_x - 5, icon_y - 5))
                shadow = pygame.Surface((icon_w, max(4, icon_h // 6)), pygame.SRCALPHA)
                pygame.draw.ellipse(shadow, (0, 0, 0, 90), shadow.get_rect())
                surf.blit(shadow, (icon_x, icon_y + icon_h - 4))
                surf.blit(item_tex, (icon_x, icon_y))
                continue
            if g["item"] == "berry":
                col = (240, 60, 80)
            elif g["item"] == "apple":
                col = (240, 188, 90)
            elif g["item"] == "boat":
                col = (100, 210, 230)
            else:
                col = (196, 170, 130)
            pygame.draw.circle(surf, col, (int(offset_x + ts // 2), int(offset_y + ts // 2 - bob)), 5)

        for w in self.weapon_spawns:
            if w["taken"]:
                continue
            x, y = w["tile"]
            offset_x = x * ts - cam_x
            offset_y = y * ts - cam_y
            item_tex = item_textures.get_item_or_placeholder(w["item"], ts) if item_textures else None
            if item_tex is not None:
                icon_w, icon_h = item_tex.get_size()
                icon_x = int(offset_x + (ts - icon_w) / 2)
                icon_y = int(offset_y + (ts - icon_h) / 2 - 4)
                glow_alpha = 60 + int(40 * (0.5 + 0.5 * math.sin(anim_time * 4 + x + y)))
                glow = pygame.Surface((icon_w + 10, icon_h + 10), pygame.SRCALPHA)
                pygame.draw.ellipse(glow, (150, 210, 255, glow_alpha), glow.get_rect())
                surf.blit(glow, (icon_x - 5, icon_y - 5))
                shadow = pygame.Surface((icon_w, max(4, icon_h // 6)), pygame.SRCALPHA)
                pygame.draw.ellipse(shadow, (0, 0, 0, 100), shadow.get_rect())
                surf.blit(shadow, (icon_x, icon_y + icon_h - 3))
                surf.blit(item_tex, (icon_x, icon_y))
                continue
            base = pygame.Rect(int(offset_x + ts / 2 - 4), int(offset_y + ts / 2 - 14), 8, 18)
            pygame.draw.rect(surf, (195, 206, 228), base)
            pygame.draw.rect(surf, (88, 72, 60), pygame.Rect(base.x - 3, base.bottom - 4, 14, 3))

from __future__ import annotations

import random
import pygame

from enemy import Enemy
import settings


class SpawnManager:
    def __init__(self, world) -> None:
        self.world = world
        self.spawn_timer = 0.0
        self.despawn_distance = 1300
        self.region_rules = {
            "forest": {"max": 10, "rate": 1.3, "types": [("slime", 0.56), ("boar", 0.34), ("bandit", 0.10)]},
            "orchard": {"max": 8, "rate": 1.4, "types": [("slime", 0.45), ("boar", 0.45), ("bandit", 0.10)]},
            "cave": {"max": 7, "rate": 1.2, "types": [("lurker", 0.68), ("bandit", 0.18), ("goblin", 0.14)]},
            "ruins": {"max": 8, "rate": 1.0, "types": [("lurker", 0.54), ("bandit", 0.39), ("boar", 0.07)]},
            "remote_camp": {"max": 5, "rate": 1.8, "types": [("bandit", 0.6), ("slime", 0.4)]},
            "dwarven_mines": {"max": 6, "rate": 1.2, "types": [("goblin", 0.72), ("lurker", 0.18), ("bandit", 0.10)]},
        }

    def _pick_type(self, region: str) -> str:
        rule = self.region_rules[region]["types"]
        roll = random.random()
        acc = 0.0
        for name, w in rule:
            acc += w
            if roll <= acc:
                return name
        return rule[-1][0]

    def _valid_spawn(self, px: float, py: float, player_pos: pygame.Vector2, enemies: list[Enemy]) -> bool:
        dist = pygame.Vector2(px, py).distance_to(player_pos)
        if dist < 260 or dist > 1000:
            return False
        r = pygame.Rect(int(px), int(py), 24, 24)
        if self.world.collides(r):
            return False
        for e in enemies:
            if not e.dead and e.rect.colliderect(r.inflate(30, 30)):
                return False
        return True

    def update(self, dt: float, player_pos: pygame.Vector2, enemies: list[Enemy], is_night: bool) -> None:
        self.spawn_timer += dt
        for e in enemies[:]:
            if e.dead:
                continue
            if pygame.Vector2(e.x, e.y).distance_to(player_pos) > self.despawn_distance:
                enemies.remove(e)

        if self.spawn_timer < 0.6:
            return
        self.spawn_timer = 0.0
        if not is_night:
            return

        for region, rule in self.region_rules.items():
            active = sum(1 for e in enemies if not e.dead and self.world.region_name_for_px(e.x, e.y) == region)
            target_rate = rule["rate"] * 1.2
            if active >= rule["max"] or random.random() > target_rate * dt * 4.3:
                continue
            rect = self.world.regions[region]
            for _ in range(25):
                tx = random.randint(rect.left, rect.right - 1)
                ty = random.randint(rect.top, rect.bottom - 1)
                px, py = tx * settings.TILE_SIZE + 4, ty * settings.TILE_SIZE + 4
                if self._valid_spawn(px, py, player_pos, enemies):
                    kind = self._pick_type(region)
                    enemies.append(Enemy(px, py, kind))
                    break

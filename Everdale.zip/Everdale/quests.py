from __future__ import annotations

from dataclasses import dataclass


@dataclass
class Quest:
    quest_id: str
    title: str
    description: str
    objective: str
    target: int
    reward_money: int
    reward_item: str | None = None
    main: bool = False


QUESTS: dict[str, Quest] = {
    "welcome_to_eldervale": Quest(
        "welcome_to_eldervale",
        "Welcome to Eldervale",
        "Find Elder Rowan in the village and hear what threatens the valley.",
        "talk_rowan",
        1,
        25,
        "apple",
        main=True,
    ),
    "forager_path": Quest(
        "forager_path",
        "Forager's Path",
        "Whisperwood berries are potent—gather 6 for Mira's remedies.",
        "collect_berry",
        6,
        30,
        "minor_potion",
    ),
    "orchard_harvest": Quest(
        "orchard_harvest",
        "Orchard Harvest",
        "The Sun Orchard west of the village is ripe—collect 5 apples.",
        "collect_apple",
        5,
        28,
        "hearty_stew",
    ),
    "cave_cleansing": Quest(
        "cave_cleansing",
        "Cave Cleansing",
        "Stonehollow Cave breeds lurkers. Clear 6 to make the path safe.",
        "kill_lurker",
        6,
        70,
        "stamina_tonic",
        main=True,
    ),
    "roadwarden_help": Quest(
        "roadwarden_help",
        "Roadwarden's Request",
        "Kael reports bandits on the eastern road—cut down 8 of them.",
        "kill_bandit",
        8,
        75,
        "iron_sword",
    ),
    "ruins_signal": Quest(
        "ruins_signal",
        "Signal in the Ruins",
        "Strange lights over the Ashen Ruins—go there and see what stirs.",
        "reach_ruins",
        1,
        50,
        None,
        main=True,
    ),
    "merchant_supply_run": Quest(
        "merchant_supply_run",
        "Supply Run",
        "Gather 4 cave mushrooms from Stonehollow, then speak to Trader Venn on the east trail to deliver them.",
        "talk_venn",
        1,
        55,
        "hearty_stew",
    ),
    "courier_note": Quest(
        "courier_note",
        "Courier's Note",
        "Find Cora and deliver the letter she asks you to carry.",
        "talk_cora",
        1,
        18,
        "herb",
    ),
    "river_rescue": Quest(
        "river_rescue",
        "River Rescue",
        "Seli needs fresh river fish to stock her stall—bring back 3.",
        "collect_fish",
        3,
        32,
        "apple",
    ),
    "dwarven_mines": Quest(
        "dwarven_mines",
        "Dwarven Mines",
        "Find Bubu the dwarf and earn his pickaxe, then he'll show you the Dwarven Mines entrance.",
        "talk_bubu",
        1,
        40,
        "pickaxe",
    ),
    "mine_supply": Quest(
        "mine_supply",
        "Mine Supply Run",
        "Collect 3 iron ore from the dwarven mine and bring it back to the village.",
        "collect_iron_ore",
        3,
        60,
        "gold_sword",
    ),
    "forest_herb": Quest(
        "forest_herb",
        "Forest Herb",
        "Collect 3 Sun Herbs for Mira's next strong elixir.",
        "collect_herb",
        3,
        34,
        "minor_potion",
    ),
    "peddler_offer": Quest(
        "peddler_offer",
        "Peddler's Offer",
        "Speak to Fen in the hidden glade and see if he has a rare trinket for travelers.",
        "talk_fen",
        1,
        45,
        "stamina_tonic",
    ),
    "night_watch": Quest(
        "night_watch",
        "Night Watch",
        "The wilds grow cruel after dark—defeat 5 foes between dusk and dawn.",
        "kill_night",
        5,
        80,
        "traveler_bow",
    ),
    "ancient_heart": Quest(
        "ancient_heart",
        "Ancient Heart",
        "Obtain an Ancient Core from the ruins or those who dwell there—Iora knows more.",
        "collect_ancient_core",
        1,
        120,
        "ruins_key",
        main=True,
    ),
    "guardian_of_ashes": Quest(
        "guardian_of_ashes",
        "Guardian of Ashes",
        "At night, a Warden awakens in the Ashen Ruins. Survive its telegraphed strikes and end it.",
        "kill_miniboss",
        1,
        220,
        None,
        main=True,
    ),
    "northern_legends": Quest(
        "northern_legends",
        "Northern Legends",
        "Elder Thorne speaks of ancient northern tales. Learn what secrets Frosthold guards.",
        "talk_thorne",
        1,
        40,
        "ancient_coin",
    ),
    "mountain_pass_explore": Quest(
        "mountain_pass_explore",
        "Mountain Pass Mystery",
        "The Highpeak Pass holds secrets. Explore and see what you can discover.",
        "reach_mountain_pass",
        1,
        35,
        None,
    ),
    "eastern_dawn": Quest(
        "eastern_dawn",
        "Eastern Dawn",
        "Dawnbreak Village welcomes travelers. Speak with Talia about eastern opportunities.",
        "talk_talia",
        1,
        45,
        "eastern_herb",
    ),
    "deepshadow_guard": Quest(
        "deepshadow_guard",
        "Deepshadow Guardian",
        "Guard Lir needs help protecting the southern cave entrance from threats.",
        "talk_lir",
        1,
        50,
        "cave_key",
    ),
    "whispering_depths": Quest(
        "whispering_depths",
        "Whispering Depths",
        "Explorer Kai has tales of the western caves. Learn about their hidden dangers.",
        "talk_kai",
        1,
        42,
        "ancient_relic",
    ),
    "frosthold_herbs": Quest(
        "frosthold_herbs",
        "Frosthold Herbs",
        "Collect 4 northern herbs from the Frosthold region for Renn's eastern remedies.",
        "collect_northern_herb",
        4,
        38,
        "hearty_stew",
    ),
    "cave_defense": Quest(
        "cave_defense",
        "Cave Defense",
        "Clear 5 lurkers from the Deepshadow Cave to make it safer for explorers.",
        "kill_lurker_deepshadow",
        5,
        65,
        "stamina_tonic",
    ),
    "eastern_fish": Quest(
        "eastern_fish",
        "Eastern Waters",
        "Bring 3 fish from the eastern river regions to help stock Dawnbreak's market.",
        "collect_eastern_fish",
        3,
        36,
        "minor_potion",
    ),
    "bandit_hunters": Quest(
        "bandit_hunters",
        "Bandit Hunters",
        "Bandits have been spotted near the mountain pass. Hunt down 6 of them.",
        "kill_bandit_mountain",
        6,
        70,
        "traveler_bow",
    ),
    "desert_exploration": Quest(
        "desert_exploration",
        "Desert Discovery",
        "Explore the eastern desert and uncover its ancient secrets.",
        "reach_desert",
        1,
        60,
        "desert_artifact",
    ),
    "swamp_mystery": Quest(
        "swamp_mystery",
        "Swamp Mystery",
        "Strange lights have been seen in the southwestern swamp. Investigate.",
        "reach_swamp",
        1,
        55,
        "swamp_herb",
    ),
    "volcano_danger": Quest(
        "volcano_danger",
        "Volcanic Threat",
        "The southeastern volcano shows signs of activity. Check it out.",
        "reach_volcano",
        1,
        65,
        "lava_crystal",
    ),
    "harbortown_help": Quest(
        "harbortown_help",
        "Harbortown Aid",
        "The new southern village needs supplies. Speak with Elder Mara.",
        "talk_mara",
        1,
        50,
        "fishing_rod",
    ),
    "temple_quest": Quest(
        "temple_quest",
        "Temple of Ancients",
        "The ancient temple in the west holds powerful artifacts.",
        "reach_temple",
        1,
        80,
        "ancient_relic",
        main=True,
    ),
    "lake_guardian": Quest(
        "lake_guardian",
        "Lake Guardian",
        "A powerful creature guards Crystal Lake. Defeat it to claim its treasure.",
        "kill_lake_boss",
        1,
        150,
        "crystal_heart",
        main=True,
    ),
    "desert_bandits": Quest(
        "desert_bandits",
        "Desert Raiders",
        "Bandits roam the southern desert. Clear 8 of them for safe passage.",
        "kill_desert_bandit",
        8,
        85,
        "desert_sword",
    ),
    "swamp_purification": Quest(
        "swamp_purification",
        "Swamp Purification",
        "The swamp is corrupted. Collect 5 purification herbs.",
        "collect_purification_herb",
        5,
        45,
        "purified_water",
    ),
    "mountain_climber": Quest(
        "mountain_climber",
        "Mountain Climber",
        "Reach the summit of the volcanic mountain and survive the heat.",
        "reach_volcano_summit",
        1,
        90,
        "fire_essence",
    ),
    "fishing_master": Quest(
        "fishing_master",
        "Fishing Master",
        "Master the art of fishing. Catch 10 rare fish from various waters.",
        "collect_rare_fish",
        10,
        75,
        "master_rod",
    ),
    "artifact_hunter": Quest(
        "artifact_hunter",
        "Artifact Hunter",
        "Find and collect 3 ancient artifacts scattered across the world.",
        "collect_ancient_artifact",
        3,
        120,
        "artifact_collection",
    ),
    "merchant_network": Quest(
        "merchant_network",
        "Merchant Network",
        "Visit all major merchants and complete their special requests.",
        "talk_all_merchants",
        1,
        100,
        "merchant_pass",
    ),
    "guardian_slayer": Quest(
        "guardian_slayer",
        "Guardian Slayer",
        "Defeat the ancient guardians protecting the sacred sites.",
        "kill_all_guardians",
        4,
        300,
        "guardian_soul",
        main=True,
    ),
}


class QuestLog:
    def __init__(self, active: list[str] | None = None, completed: list[str] | None = None) -> None:
        self.active: dict[str, int] = {}
        self.completed: set[str] = set(completed or [])
        for quest_id in (active or []):
            if quest_id in QUESTS and quest_id not in self.completed:
                self.active[quest_id] = 0

    def ensure(self, quest_id: str) -> None:
        if quest_id in QUESTS and quest_id not in self.completed and quest_id not in self.active:
            self.active[quest_id] = 0

    def progress(self, objective: str, amount: int = 1) -> list[str]:
        completed_now: list[str] = []
        for quest_id in list(self.active):
            quest = QUESTS[quest_id]
            if quest.objective != objective:
                continue
            self.active[quest_id] = min(quest.target, self.active[quest_id] + amount)
            if self.active[quest_id] >= quest.target:
                completed_now.append(quest_id)
        return completed_now

    def complete(self, quest_id: str) -> bool:
        if quest_id not in self.active:
            return False
        self.active.pop(quest_id, None)
        self.completed.add(quest_id)
        return True

    def active_entries(self) -> list[tuple[Quest, int]]:
        return [(QUESTS[qid], prog) for qid, prog in self.active.items() if qid in QUESTS]

    def to_dict(self) -> dict:
        return {"active": dict(self.active), "completed": sorted(self.completed)}

@echo off
cd /d "%~dp0"
setlocal

set "PY_EXEC="
where py >nul 2>&1
if %errorlevel% equ 0 (
    set "PY_EXEC=py -3"
) else (
    where python >nul 2>&1
    if %errorlevel% equ 0 (
        set "PY_EXEC=python"
    ) else (
        echo Python not found. Attempting install via winget...
        winget install --id Python.Python.3 -e --source winget
        if %errorlevel% neq 0 (
            echo Winget install failed. Please install Python 3 manually from https://www.python.org/downloads/
            pause
            exit /b 1
        )
        set "PY_EXEC=py -3"
    )
)

%PY_EXEC% -c "import pygame" >nul 2>&1
if %errorlevel% neq 0 (
    echo Installing pygame...
    %PY_EXEC% -m pip install pygame
    if %errorlevel% neq 0 (
        echo Failed to install pygame. Install it manually and rerun this script.
        pause
        exit /b 1
    )
)

%PY_EXEC% main.py

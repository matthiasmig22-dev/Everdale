from __future__ import annotations

import pygame


class AudioManager:
    """
    Placeholder audio hooks.
    Uses generated beeps so no external files are required.
    """

    def __init__(self) -> None:
        self.music_volume = 0.35
        self.sfx_volume = 0.6
        self.current_track = "menu"
        self._channel = pygame.mixer.Channel(0) if pygame.mixer.get_init() else None

    def set_music_volume(self, v: float) -> None:
        self.music_volume = max(0.0, min(1.0, v))

    def set_sfx_volume(self, v: float) -> None:
        self.sfx_volume = max(0.0, min(1.0, v))

    def play_music_for_region(self, region: str, boss: bool = False) -> None:
        # Hook for real music files later.
        self.current_track = "boss" if boss else region

    def sfx(self, name: str) -> None:
        # Hook for real sounds; intentionally silent-safe.
        _ = name

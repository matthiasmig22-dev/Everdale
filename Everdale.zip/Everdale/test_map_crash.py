#!/usr/bin/env python3
"""Test if the map crashes."""
import sys, traceback, pygame

def test_map():
    try:
        pygame.init()
        pygame.display.set_mode((1280, 720))
        from game import Game, GameState
        game = Game(pygame.display.get_surface(), pygame.time.Clock())
        game.state = GameState.MAP
        game.render()
        print("✓ Map renders successfully - NO CRASH")
        return True
    except Exception as e:
        print(f"✗ CRASH FOUND: {type(e).__name__}: {e}")
        traceback.print_exc()
        return False
    finally:
        pygame.quit()

sys.exit(0 if test_map() else 1)

#!/usr/bin/env python3
"""Generate a procedural heightmap for a large immersive world - optimized with NumPy."""

import numpy as np
from PIL import Image
import random

def create_heightmap(width=1920, height=1440, seed=42):
    """Generate a large procedural heightmap with diverse, more walkable terrain."""
    rng = np.random.RandomState(seed)
    
    # Create coordinate grids
    x, y = np.meshgrid(np.arange(width), np.arange(height))
    hmap = np.zeros((height, width), dtype=np.float32)
    
    # Large-scale landmass noise (smoother transitions)
    hmap += 0.5 * np.sin(x / 250) * np.cos(y / 250)
    hmap += 0.3 * np.sin(x / 400) * np.cos(y / 400)
    
    # Medium-scale variation
    hmap += 0.2 * np.sin(x / 80) * np.cos(y / 80)
    
    # Add some random noise for organic feel
    hmap += rng.normal(0, 0.03, (height, width))
    
    # Rolling hills everywhere (base terrain more walkable)
    hmap += 0.2 * np.sin(x / 120) * np.cos(y / 120)
    
    # Mountain range (northeast corner) - but not too tall
    cy_mountain, cx_mountain = int(height * 0.15), int(width * 0.75)
    dist_mountain = np.sqrt((x - cx_mountain) ** 2 + (y - cy_mountain) ** 2) / 350
    hmap += np.maximum(0, 0.8 - dist_mountain * 0.8) * 0.5
    
    # Volcano (southeast) - moderate height
    cy_volcano, cx_volcano = int(height * 0.7), int(width * 0.8)
    dist_volcano = np.sqrt((x - cx_volcano) ** 2 + (y - cy_volcano) ** 2) / 300
    hmap += np.maximum(0, 0.7 - dist_volcano * 0.8) * 0.4
    
    # Deep lake/ocean basin (west-center) - create water body
    cy_lake, cx_lake = int(height * 0.45), int(width * 0.1)
    dist_lake = np.sqrt((x - cx_lake) ** 2 + (y - cy_lake) ** 2) / 320
    hmap -= np.maximum(0, 0.9 - dist_lake) * np.minimum(1.0, dist_lake < 1.3) * 0.7
    
    # Forest/woodland (north-center) - elevated but walkable
    cy_forest, cx_forest = int(height * 0.3), int(width * 0.5)
    dist_forest = np.sqrt((x - cx_forest) ** 2 + (y - cy_forest) ** 2) / 380
    hmap += np.maximum(0, 0.6 - dist_forest) * 0.3
    
    # Desert plateau (southwest) - low gentle area
    cy_desert, cx_desert = int(height * 0.8), int(width * 0.2)
    dist_desert = np.sqrt((x - cx_desert) ** 2 + (y - cy_desert) ** 2) / 350
    hmap -= np.maximum(0, 0.5 - dist_desert) * 0.4
    
    # Swamp/wetlands (southeast-low) - marshy area
    cy_swamp, cx_swamp = int(height * 0.75), int(width * 0.65)
    dist_swamp = np.sqrt((x - cx_swamp) ** 2 + (y - cy_swamp) ** 2) / 300
    hmap -= np.maximum(0, 0.6 - dist_swamp) * 0.35
    
    # Normalize to 0-1
    hmap = (hmap - hmap.min()) / (hmap.max() - hmap.min() + 1e-6)
    hmap = np.clip(hmap, 0, 1)
    
    # Better smoothing for natural look
    for _ in range(2):
        hmap = (hmap + np.roll(hmap, 1, axis=0) + np.roll(hmap, 1, axis=1) + 
                np.roll(hmap, -1, axis=0) + np.roll(hmap, -1, axis=1)) / 5
    
    # Convert to 8-bit grayscale
    hmap_8bit = (hmap * 255).astype(np.uint8)
    
    # Create and save image
    img = Image.fromarray(hmap_8bit, mode='L')
    img.save('/home/thrussianwombat/Desktop/coding projects/Everdale/assets/heightmap.png')
    print(f"Heightmap saved: {width}x{height} (more immersive)")
    return hmap

if __name__ == '__main__':
    create_heightmap()

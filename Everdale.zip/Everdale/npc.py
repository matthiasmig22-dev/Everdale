from __future__ import annotations

from dataclasses import dataclass, field
import pygame

from asset_helpers import NPCTextureBank


@dataclass
class NPC:
    npc_id: str
    name: str
    role: str
    x: float
    y: float
    dialogue: list[str]
    age_group: str = "middle"
    quest_hint: str = ""
    shop_id: str | None = None
    path_points: list[tuple[int, int]] | None = field(default=None)
    speed: float = 34.0
    wait_timer: float = 0.0
    target_index: int = 0

    @property
    def rect(self) -> pygame.Rect:
        return pygame.Rect(int(self.x), int(self.y), 24, 24)

    def update(self, dt: float, world_collides) -> None:
        if not self.path_points:
            return
        if self.wait_timer > 0:
            self.wait_timer = max(0.0, self.wait_timer - dt)
            return
        target_tile = self.path_points[self.target_index]
        target = pygame.Vector2(target_tile[0] * 32 + 4, target_tile[1] * 32 + 4)
        current = pygame.Vector2(self.x, self.y)
        direction = target - current
        distance = direction.length()
        if distance < 2:
            self.target_index = (self.target_index + 1) % len(self.path_points)
            self.wait_timer = 1.0
            return
        movement = direction.normalize() * self.speed * dt
        if movement.length() > distance:
            movement = direction
        
        # Check if movement would put us on water
        test_rect = pygame.Rect(int(self.x + movement.x), int(self.y + movement.y), 24, 24)
        if world_collides(test_rect):
            # Try to find an alternative direction around the obstacle
            # Simple avoidance: try moving perpendicular to the target
            perp_direction = pygame.Vector2(-direction.y, direction.x).normalize()
            alt_movement = perp_direction * self.speed * dt
            alt_rect = pygame.Rect(int(self.x + alt_movement.x), int(self.y + alt_movement.y), 24, 24)
            if not world_collides(alt_rect):
                movement = alt_movement
            else:
                # Try the other perpendicular direction
                perp_direction2 = pygame.Vector2(direction.y, -direction.x).normalize()
                alt_movement2 = perp_direction2 * self.speed * dt
                alt_rect2 = pygame.Rect(int(self.x + alt_movement2.x), int(self.y + alt_movement2.y), 24, 24)
                if not world_collides(alt_rect2):
                    movement = alt_movement2
                else:
                    # Can't move, wait longer
                    self.wait_timer = 2.0
                    return
        
        self.x += movement.x
        self.y += movement.y

    def draw(self, surf: pygame.Surface, cam_x: float, cam_y: float, npc_textures: NPCTextureBank | None = None) -> None:
        r = self.rect.move(-int(cam_x), -int(cam_y))
        if npc_textures is not None:
            texture = npc_textures.get(self.age_group)
            surf.blit(texture, r)
            return
        color = (212, 215, 130) if self.shop_id else (148, 190, 240)
        pygame.draw.rect(surf, color, r, border_radius=4)


def build_npcs() -> list[NPC]:
    # 19 named NPCs across village + remote regions (scaled 3x for massive world)
    return [
        NPC("rowan", "Elder Rowan", "elder", 132 * 32, 108 * 32, ["Welcome, traveler. Eldervale needs your courage.", "The ruins awaken as night falls."], age_group="old", quest_hint="Talk to villagers."),
        NPC("mira", "Mira", "herbalist", 84 * 32, 144 * 32, ["Bring me fresh berries and I'll brew a remedy.", "Herbs from the forest carry strong vitality."], age_group="middle", quest_hint="Collect berries."),
        NPC("tobin", "Tobin", "farmer", 180 * 32, 144 * 32, ["The orchard has apples this week.", "Boars have been trampling crops."], age_group="middle"),
        NPC("lyra", "Lyra", "food seller", 156 * 32, 84 * 32, ["Warm meals for road-worn heroes.", "Rainy days call for hearty stew."], age_group="middle", shop_id="village_food"),
        NPC("orra", "Orra", "general merchant", 66 * 32, 84 * 32, ["Stock up before heading east.", "If you find relics, I pay fair coin."], age_group="middle", shop_id="village_goods"),
        NPC("kael", "Kael", "roadwarden", 516 * 32 + 4, 564 * 32 + 4, ["Bandits stalk the road at dusk.", "Keep your blade ready out there."], path_points=[(516, 564), (564, 318), (744, 330), (516, 336)]),
        NPC("venn", "Trader Venn", "traveling merchant", 516 * 32 + 4, 336 * 32 + 4, ["Supplies from cave to coast.", "Bring mushrooms for a better deal."], shop_id="road_trader", path_points=[(516, 336), (564, 318), (744, 330), (516, 564)]),
        NPC("cora", "Cora", "courier", 132 * 32 + 4, 192 * 32 + 4, ["The road is livelier with every passing traveler.", "I carry letters between the village and the camp."], "Deliver the courier's note.", path_points=[(132, 192), (132, 120), (222, 120), (516, 120), (564, 318), (516, 564)]),
        NPC("sylas", "Sylas", "camp guard", 516 * 32 + 8, 588 * 32 + 4, ["This camp keeps the trail safe.", "Rest by the fire before you head east."], "Keep watch over the road."),
        NPC("alyn", "Alyn", "forest guide", 108 * 32, 252 * 32, ["Whisperwood is full of secrets.", "Trees move slower than travelers."], "Learn the safe path through the woods."),
        NPC("seli", "Seli", "fisher", 312 * 32, 348 * 32, ["The river whispers before storms.", "I sell fishing rods for fresh river catches."], "Bring fish to stock the market.", shop_id="river_fisher"),
        NPC(
            "bubu",
            "Bubu",
            "dwarf blacksmith",
            138 * 32,
            108 * 32,
            ["A good pickaxe will take you deep into the mine.", "The Dwarven Mines lie east of the river bend, past the old stone bridge."],
            age_group="middle",
            quest_hint="Mine the dwarven shaft.",
            shop_id="village_blacksmith",
        ),
        NPC("bram", "Bram", "cave explorer", 768 * 32, 156 * 32, ["Stonehollow is deeper than it looks.", "Lurkers hate torchlight."]),
        NPC("iora", "Iora", "relic seeker", 828 * 32, 516 * 32, ["Ancient cores power old mechanisms.", "One key opens the sealed heart."], shop_id="ruins_relics"),
        NPC("fen", "Fen", "hidden peddler", 990 * 32, 120 * 32, ["Not many find this glade.", "Rare goods for curious wanderers."], shop_id="hidden_rare"),
        NPC("thara", "Thara", "bridge keeper", 744 * 32 + 4, 330 * 32 + 4, ["The bridge is safer than it looks when I'm on watch.", "The river swells after rain—mind your footing."], age_group="middle", quest_hint="Ask about the bridge route."),
        NPC("nessa", "Nessa", "herbalist", 342 * 32, 204 * 32, ["I collect moonvine near the falls.", "Herbs love the cool spray of river mist."], age_group="middle", quest_hint="Learn where the best herbs grow."),
        NPC("ida", "Ida", "fisherwoman", 294 * 32, 372 * 32, ["The river gives more than fish if you pay attention.", "A fresh catch makes for a better stew."], age_group="middle", quest_hint="Bring fish for the riverside camp."),
        NPC("joren", "Joren", "ruins scout", 840 * 32, 564 * 32, ["This path into the ruins twists at night.", "I keep watch for strange shadows."], age_group="middle", quest_hint="Ask about ruins dangers."),
        NPC("lina", "Little Lina", "child", 148 * 32, 152 * 32, ["I love exploring the orchard!", "Can I come explore with you?"], age_group="child"),
        NPC("milo", "Milo", "child", 170 * 32, 150 * 32, ["I dream of sailing the sea.", "Do you have any stories?"], age_group="child"),
        NPC("eric", "Eric", "apprentice", 162 * 32, 96 * 32, ["I'm learning from Thane in the forge.", "Tools can be friends if you treat them right."], age_group="middle"),
        NPC("henry", "Old Henry", "elder", 360 * 32, 210 * 32, ["I've watched this village grow for decades.", "Listen to the wind—it's humming again."], age_group="old", quest_hint="Learn village tales."),
        NPC("ari", "Ari", "child", 570 * 32, 120 * 32, ["The river's fish are playful today.", "Do you want to see my collection?"], age_group="child"),
        # New NPCs for additional villages (scaled 3x)
        NPC("thorne", "Elder Thorne", "elder", 432 * 32, 72 * 32, ["Frosthold stands against the northern winds.", "The mountain pass holds ancient secrets."], age_group="old", quest_hint="Learn about northern legends."),
        NPC("talia", "Talia", "merchant", 864 * 32, 408 * 32, ["Eastern wares for western travelers.", "The dawn brings new opportunities."], age_group="middle", shop_id="east_village_goods"),
        NPC("renn", "Renn", "herbalist", 924 * 32, 408 * 32, ["Eastern herbs have unique properties.", "The sun rises with healing light."], age_group="middle", quest_hint="Collect eastern herbs."),
        NPC("lir", "Guard Lir", "guard", 288 * 32, 708 * 32, ["Deepshadow guards its secrets well.", "Not all who enter the depths return."], "Guard the southern cave entrance."),
        NPC("kai", "Explorer Kai", "explorer", 72 * 32, 462 * 32, ["Whispering Depths echo with forgotten tales.", "Some caves are meant to stay hidden."], "Explore the western caves."),
        # New NPCs for expanded world (scaled 3x)
        NPC("mara", "Elder Mara", "elder", 585 * 32, 1245 * 32, ["Harbortown welcomes all travelers.", "The sea brings both bounty and danger."], age_group="old", quest_hint="Learn about southern opportunities."),
        NPC("soren", "Captain Soren", "captain", 555 * 32, 1215 * 32, ["The waves are restless today.", "Many ships have been lost to storms."], age_group="middle", quest_hint="Ask about sea voyages."),
        NPC("lynn", "Lynn", "merchant", 615 * 32, 1215 * 32, ["Fresh catch from the harbor.", "Trade winds bring exotic goods."], shop_id="harbor_goods"),
        NPC("thane", "Thane", "blacksmith", 645 * 32, 1245 * 32, ["Quality weapons for quality adventurers.", "The volcano forges the finest steel."], shop_id="southern_forge"),
        NPC("sable", "Sable", "alchemist", 525 * 32, 1275 * 32, ["Potions brewed with desert herbs.", "The sands hold many secrets."], "Collect desert ingredients."),
        NPC("kor", "Kor", "desert_guide", 1680 * 32, 1230 * 32, ["The desert tests the worthy.", "Ancient ruins lie beneath the sands."], "Guide through the eastern desert."),
        NPC("mira_desert", "Mira", "desert_merchant", 1710 * 32, 1260 * 32, ["Rare goods from across the wastes.", "The desert traders know many paths."], shop_id="desert_trader"),
        NPC("volk", "Volk", "volcano_smith", 1800 * 32, 1251 * 32, ["Forged in fire, tempered in lava.", "The mountain's heat never dies."], "Learn about volcanic crafting."),
        NPC("sylph", "Sylph", "swamp_witch", 255 * 32, 1080 * 32, ["The swamp whispers ancient secrets.", "Nature's balance must be maintained."], "Learn swamp lore."),
        NPC("reed", "Reed", "swamp_guide", 225 * 32, 1050 * 32, ["I know every hidden path in the mire.", "The swamp gives and the swamp takes."], "Navigate the southwestern swamp."),
        NPC("temple_keeper", "Temple Keeper", "guardian", 216 * 32, 360 * 32, ["The temple tests those who seek wisdom.", "Only the worthy may enter the sanctum."], "Guard the ancient temple."),
        NPC("lake_spirit", "Lake Spirit", "mystical", 405 * 32, 276 * 32, ["The waters reflect the soul's true nature.", "Crystal Lake holds ancient power."], "Learn about the lake's magic."),
        NPC("mountain_hermit", "Mountain Hermit", "wise", 1101 * 32, 495 * 32, ["The peaks offer clarity of mind.", "From high places, one sees far."], "Seek wisdom from the heights."),
        NPC("forest_druid", "Forest Druid", "nature", 345 * 32, 486 * 32, ["The forest breathes with us.", "Balance is the key to harmony."], "Learn forest secrets."),
        NPC("ruins_explorer", "Ruins Explorer", "archaeologist", 705 * 32, 381 * 32, ["These ruins tell stories of the past.", "Each stone has a tale to tell."], "Explore northern ruins."),
        NPC("west_ruins_keeper", "West Ruins Keeper", "historian", 75 * 32, 1125 * 32, ["The western ruins guard forgotten knowledge.", "Time has not erased their power."], "Study western ruins."),
    ]

from __future__ import annotations

import math
import pygame
from asset_helpers import draw_player_sprite, PlayerTextureBank


class Player:
    def __init__(self, x: float, y: float, char_type: str = "human", texture_bank: PlayerTextureBank | None = None) -> None:
        self.x = x
        self.y = y
        self.w = 20
        self.h = 20
        self.speed = 150.0
        self.sprint_mult = 1.65
        self.roll_speed = 360.0
        self.roll_timer = 0.0
        self.roll_cooldown = 0.0
        self.face = pygame.Vector2(1, 0)
        self.char_type = char_type
        self.texture_bank = texture_bank if texture_bank is not None else PlayerTextureBank()
        self.walk_timer = 0.0

        self.max_health = 100.0
        self.health = 100.0
        self.max_stamina = 100.0
        self.stamina = 100.0

        self.level = 1
        self.xp = 0
        self.xp_to_next = 100

        self.attack_cooldown = 0.0
        self.attack_timer = 0.0
        self.hit_flash = 0.0
        self.iframes = 0.0
        self.hit_enemy_ids: set[int] = set()

    @property
    def rect(self) -> pygame.Rect:
        return pygame.Rect(int(self.x), int(self.y), self.w, self.h)

    def to_dict(self) -> dict:
        return {
            "x": round(self.x, 2),
            "y": round(self.y, 2),
            "health": round(self.health, 2),
            "stamina": round(self.stamina, 2),
            "level": self.level,
            "xp": self.xp,
            "char_type": self.char_type,
        }

    def load_dict(self, data: dict) -> None:
        self.x = data.get("x", self.x)
        self.y = data.get("y", self.y)
        self.char_type = data.get("char_type", self.char_type)
        self.level = int(data.get("level", self.level))
        self.xp = int(data.get("xp", self.xp))
        self.xp_to_next = 100 + (self.level - 1) * 50
        self.max_health = 100 + (self.level - 1) * 10
        self.max_stamina = 200 + (self.level - 1) * 8
        self.health = min(float(data.get("health", self.health)), self.max_health)
        self.stamina = min(float(data.get("stamina", self.stamina)), self.max_stamina)

    def add_xp(self, amount: int) -> None:
        if amount <= 0:
            return
        self.xp += amount
        while self.xp >= self.xp_to_next:
            self.xp -= self.xp_to_next
            self.level += 1
            self.xp_to_next = 100 + (self.level - 1) * 50
            self.max_health += 10
            self.max_stamina += 8
            self.health = min(self.max_health, self.health + 10)
            self.stamina = min(self.max_stamina, self.stamina + 8)

    def update_needs(self, dt: float) -> None:
        # Passive regeneration with no hunger mechanic.
        self.health = min(self.max_health, self.health + 0.8 * dt)

        if self.roll_timer <= 0:
            self.stamina = min(self.max_stamina, self.stamina + 20.0 * dt)

        self.attack_cooldown = max(0.0, self.attack_cooldown - dt)
        self.attack_timer = max(0.0, self.attack_timer - dt)
        self.roll_timer = max(0.0, self.roll_timer - dt)
        self.roll_cooldown = max(0.0, self.roll_cooldown - dt)
        self.iframes = max(0.0, self.iframes - dt)
        self.hit_flash = max(0.0, self.hit_flash - dt)

    def movement_vector(self, key_state: dict[str, bool]) -> pygame.Vector2:
        x = (1 if key_state.get("move_right") else 0) - (1 if key_state.get("move_left") else 0)
        y = (1 if key_state.get("move_down") else 0) - (1 if key_state.get("move_up") else 0)
        vec = pygame.Vector2(x, y)
        if vec.length_squared() > 0:
            vec = vec.normalize()
            self.face = vec
        return vec

    def move_with_collision(self, move: pygame.Vector2, dt: float, world_collides) -> None:
        if move.length_squared() <= 0:
            return
        nx = self.x + move.x * dt
        ny = self.y + move.y * dt
        test_x = pygame.Rect(int(nx), int(self.y), self.w, self.h)
        if not world_collides(test_x):
            self.x = nx
        test_y = pygame.Rect(int(self.x), int(ny), self.w, self.h)
        if not world_collides(test_y):
            self.y = ny

    def get_speed(self, sprinting: bool) -> float:
        if self.roll_timer > 0:
            return self.roll_speed
        if sprinting and self.stamina > 0:
            return self.speed * self.sprint_mult
        return self.speed

    def spend_stamina_for_sprint(self, sprinting: bool, dt: float) -> None:
        if sprinting and self.stamina > 0:
            self.stamina = max(0.0, self.stamina - 24.0 * dt)

    def try_roll(self) -> bool:
        if self.roll_cooldown > 0 or self.stamina < 25:
            return False
        self.roll_timer = 0.22
        self.roll_cooldown = 0.55
        self.stamina -= 25
        self.iframes = 0.18
        return True

    def try_attack(self) -> bool:
        if self.attack_cooldown > 0:
            return False
        self.attack_timer = 0.18
        self.attack_cooldown = 0.32
        self.hit_enemy_ids.clear()
        return True

    def attack_rect(self) -> pygame.Rect:
        r = self.rect
        dist = 20
        size = 34
        dx = int(round(self.face.x))
        dy = int(round(self.face.y))
        if abs(self.face.x) > abs(self.face.y):
            return pygame.Rect(r.centerx + dx * dist - size // 2, r.centery - size // 2, size, size)
        return pygame.Rect(r.centerx - size // 2, r.centery + dy * dist - size // 2, size, size)

    def take_damage(self, amount: float) -> bool:
        if self.iframes > 0:
            return False
        self.health = max(0.0, self.health - amount)
        self.hit_flash = 0.2
        self.iframes = 0.35
        return True

    def update_animation(self, dt: float, moving: bool) -> None:
        if moving:
            self.walk_timer = min(self.walk_timer + dt * 10.0, 3.9)
        else:
            self.walk_timer = max(self.walk_timer - dt * 16.0, 0.0)

    def _direction_index(self) -> int:
        if abs(self.face.x) > abs(self.face.y):
            return 2 if self.face.x > 0 else 1
        return 0 if self.face.y > 0 else 3

    def draw(self, surf: pygame.Surface, cam_x: float, cam_y: float) -> None:
        r = self.rect.move(-int(cam_x), -int(cam_y))
        direction = self._direction_index()
        frame = int(self.walk_timer) % 4 if self.walk_timer > 0 else 0
        sprite = self.texture_bank.get(self.char_type, direction, frame)
        if self.hit_flash > 0:
            sprite = sprite.copy()
            sprite.fill((255, 255, 255, 80), special_flags=pygame.BLEND_RGBA_ADD)
        sprite_rect = sprite.get_rect(center=r.center)
        surf.blit(sprite, sprite_rect.topleft)
        if self.attack_timer > 0:
            ar = self.attack_rect().move(-int(cam_x), -int(cam_y))
            slash = pygame.Surface((ar.w, ar.h), pygame.SRCALPHA)
            pygame.draw.ellipse(slash, (255, 240, 180, 120), slash.get_rect(), 2)
            surf.blit(slash, ar.topleft)

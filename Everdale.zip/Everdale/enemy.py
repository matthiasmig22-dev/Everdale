from __future__ import annotations

import random
import pygame
from asset_helpers import draw_enemy_sprite


ENEMY_STATS = {
    "slime": {"hp": 20, "speed": 70, "damage": 6, "range": 18, "color": (103, 212, 125), "coin": (1, 4)},
    "boar": {"hp": 32, "speed": 92, "damage": 9, "range": 18, "color": (180, 128, 88), "coin": (2, 6)},
    "bandit": {"hp": 46, "speed": 100, "damage": 13, "range": 20, "color": (201, 92, 77), "coin": (4, 10)},
    "lurker": {"hp": 62, "speed": 88, "damage": 16, "range": 24, "color": (138, 103, 186), "coin": (6, 14)},
    "ruins_warden": {"hp": 240, "speed": 72, "damage": 26, "range": 32, "color": (230, 182, 114), "coin": (35, 55)},
    "goblin": {"hp": 40, "speed": 100, "damage": 12, "range": 18, "color": (120, 180, 80), "coin": (3, 8)}
}


class Enemy:
    def __init__(self, x: float, y: float, kind: str) -> None:
        self.x, self.y, self.kind = x, y, kind
        st = ENEMY_STATS[kind]
        self.hp = float(st["hp"])
        self.max_hp = float(st["hp"])
        self.speed = float(st["speed"])
        self.damage = float(st["damage"])
        self.range = float(st["range"])
        self.color = st["color"]
        self.w = 24 if kind != "ruins_warden" else 40
        self.h = 24 if kind != "ruins_warden" else 40
        self.state = "roam"
        self.roam_dir = pygame.Vector2(random.uniform(-1, 1), random.uniform(-1, 1)).normalize()
        self.roam_timer = random.uniform(0.8, 1.8)
        self.attack_cd = 0.0
        self.hit_flash = 0.0
        self.dead = False
        # Boss (Ruins Warden) — telegraphed strikes + phase-2 dash
        self.boss_windup = 0.0
        self.boss_dash_t = 0.0
        self.boss_dash_dir = pygame.Vector2(1, 0)
        self.boss_dash_cd = 0.0
        self.boss_phase_announced = False

    @property
    def rect(self) -> pygame.Rect:
        return pygame.Rect(int(self.x), int(self.y), self.w, self.h)

    @property
    def is_boss(self) -> bool:
        return self.kind == "ruins_warden"

    @property
    def boss_phase(self) -> int:
        if not self.is_boss:
            return 1
        return 2 if self.hp <= self.max_hp * 0.42 else 1

    def take_damage(self, dmg: float) -> bool:
        self.hp -= dmg
        self.hit_flash = 0.15
        if self.hp <= 0 and not self.dead:
            self.dead = True
            return True
        return False

    def update(self, dt: float, player_rect: pygame.Rect, world_collides, night_boost: float = 1.0) -> float:
        self.attack_cd = max(0.0, self.attack_cd - dt)
        self.hit_flash = max(0.0, self.hit_flash - dt)
        if self.dead:
            return 0.0
        if self.is_boss:
            return self._update_boss(dt, player_rect, world_collides, night_boost)
        return self._update_normal(dt, player_rect, world_collides, night_boost)

    def _update_normal(self, dt: float, player_rect: pygame.Rect, world_collides, night_boost: float) -> float:
        to_p = pygame.Vector2(player_rect.centerx - self.rect.centerx, player_rect.centery - self.rect.centery)
        d = to_p.length()
        if d < 180:
            self.state = "chase"
        elif d > 260:
            self.state = "roam"
        vel = pygame.Vector2()
        if self.state == "chase" and d > 0:
            vel = to_p.normalize() * self.speed * night_boost
        else:
            self.roam_timer -= dt
            if self.roam_timer <= 0:
                self.roam_timer = random.uniform(0.8, 2.1)
                v = pygame.Vector2(random.uniform(-1, 1), random.uniform(-1, 1))
                self.roam_dir = v.normalize() if v.length_squared() > 0 else pygame.Vector2(1, 0)
            vel = self.roam_dir * self.speed * 0.45

        self._move(vel, dt, world_collides)

        hit_rect = player_rect.inflate(self.range, self.range)
        if self.rect.colliderect(hit_rect) and self.attack_cd <= 0:
            self.attack_cd = 0.9 if self.kind != "ruins_warden" else 0.7
            return self.damage
        return 0.0

    def _update_boss(self, dt: float, player_rect: pygame.Rect, world_collides, night_boost: float) -> float:
        to_p = pygame.Vector2(player_rect.centerx - self.rect.centerx, player_rect.centery - self.rect.centery)
        d = to_p.length()
        phase = self.boss_phase
        spd = self.speed * (1.12 if phase == 2 else 1.0) * night_boost

        self.boss_dash_cd = max(0.0, self.boss_dash_cd - dt)

        vel = pygame.Vector2()
        if self.boss_dash_t > 0:
            self.boss_dash_t = max(0.0, self.boss_dash_t - dt)
            vel = self.boss_dash_dir * 420.0
            self._move(vel, dt, world_collides)
            hit_rect = player_rect.inflate(22, 22)
            if self.rect.colliderect(hit_rect):
                self.boss_dash_t = 0.0
                self.boss_dash_cd = 2.2
                return self.damage * 0.85
            return 0.0

        if d < 200:
            self.state = "chase"
        elif d > 300:
            self.state = "roam"

        if self.state == "chase" and d > 0 and phase == 2 and self.boss_dash_cd <= 0 and d > 100 and random.random() < 0.012:
            self.boss_dash_t = 0.28
            self.boss_dash_dir = to_p.normalize() if d > 0 else pygame.Vector2(1, 0)
            self.boss_dash_cd = 3.0 + random.uniform(0, 0.8)
            self.boss_windup = 0.0
            return 0.0

        if self.state == "chase" and d > 0:
            vel = to_p.normalize() * spd
        else:
            self.roam_timer -= dt
            if self.roam_timer <= 0:
                self.roam_timer = random.uniform(0.8, 2.1)
                v = pygame.Vector2(random.uniform(-1, 1), random.uniform(-1, 1))
                self.roam_dir = v.normalize() if v.length_squared() > 0 else pygame.Vector2(1, 0)
            vel = self.roam_dir * spd * 0.4

        self._move(vel, dt, world_collides)

        # Telegraph: wind up in melee, then one strike (dodgeable)
        melee = player_rect.inflate(self.range + 8, self.range + 8)
        in_melee = self.rect.colliderect(melee)
        windup_need = 0.52 if phase == 1 else 0.36

        if self.boss_windup > 0:
            self.boss_windup = max(0.0, self.boss_windup - dt)
            if not in_melee:
                self.boss_windup = 0.0
                return 0.0
            if self.boss_windup <= 0 and in_melee:
                self.attack_cd = 1.15 if phase == 1 else 0.85
                return self.damage * (1.15 if phase == 2 else 1.0)
            return 0.0

        if in_melee and self.attack_cd <= 0 and self.boss_dash_t <= 0:
            self.boss_windup = windup_need
        return 0.0

    def _move(self, vel: pygame.Vector2, dt: float, world_collides) -> None:
        nx = self.x + vel.x * dt
        ny = self.y + vel.y * dt
        rx = pygame.Rect(int(nx), int(self.y), self.w, self.h)
        if not world_collides(rx):
            self.x = nx
        else:
            self.roam_dir *= -1
        ry = pygame.Rect(int(self.x), int(ny), self.w, self.h)
        if not world_collides(ry):
            self.y = ny
        else:
            self.roam_dir *= -1

    def drop_loot(self) -> tuple[int, str | None]:
        c0, c1 = ENEMY_STATS[self.kind]["coin"]
        coins = random.randint(c0, c1)
        roll = random.random()
        if self.kind == "slime":
            return coins, "berry" if roll < 0.45 else None
        if self.kind == "boar":
            return coins, "apple" if roll < 0.35 else "herb" if roll < 0.55 else None
        if self.kind == "bandit":
            return coins, "minor_potion" if roll < 0.22 else None
        if self.kind == "lurker":
            return coins, "mushroom" if roll < 0.3 else "ancient_core" if roll < 0.38 else None
        if self.kind == "ruins_warden":
            if roll < 0.65:
                return coins + 30, "ancient_core"
            return coins + 12, "hearty_stew" if roll < 0.85 else "stamina_tonic"
        return coins, None

    def draw(self, surf: pygame.Surface, cam_x: float, cam_y: float) -> None:
        r = self.rect.move(-int(cam_x), -int(cam_y))
        phase = abs((self.x * 0.03 + self.y * 0.02) % 1.0)
        col = self.color
        if self.is_boss and self.boss_phase == 2:
            col = (min(255, col[0] + 35), min(255, col[1] + 20), col[2])
        draw_enemy_sprite(surf, r, col, phase, self.hit_flash > 0)

        if self.is_boss:
            pr = 28 + int((1.0 - min(1.0, self.boss_windup / 0.55)) * 36) if self.boss_windup > 0 else 0
            if pr > 0:
                cx, cy = r.centerx, r.centery
                alpha = int(80 + 120 * (1.0 - self.boss_windup / 0.55))
                ring = pygame.Surface((pr * 2 + 4, pr * 2 + 4), pygame.SRCALPHA)
                pygame.draw.circle(ring, (255, 60, 60, alpha), (pr + 2, pr + 2), pr, 2)
                surf.blit(ring, (cx - pr - 2, cy - pr - 2))

        ratio = max(0.0, self.hp / self.max_hp)
        bw = r.w + 16 if self.is_boss else r.w
        bx = r.centerx - bw // 2
        bg = pygame.Rect(bx, r.y - 10, bw, 6)
        fg = pygame.Rect(bx, r.y - 10, int(bw * ratio), 6)
        pygame.draw.rect(surf, (25, 22, 28), bg, border_radius=2)
        pygame.draw.rect(surf, (255, 90, 90) if self.is_boss else (220, 70, 70), fg, border_radius=2)
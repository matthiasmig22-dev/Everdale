from __future__ import annotations


SHOPS = {
    "village_food": {
        "name": "Lyra's Kitchen",
        "items": {"apple": 8, "berry": 6, "hearty_stew": 30, "fish": 14},
    },
    "village_goods": {
        "name": "Orra's Provisions",
        "items": {"minor_potion": 22, "stamina_tonic": 24, "herb": 12},
    },
    "road_trader": {
        "name": "Venn's Trail Cart",
        "items": {"mushroom": 10, "hearty_stew": 32, "minor_potion": 24, "iron_sword": 95},
    },
    "river_fisher": {
        "name": "River Fisher",
        "items": {"fishing_rod": 45, "fish": 14, "seaweed": 8},
    },
    "village_blacksmith": {
        "name": "Village Blacksmith",
        "items": {"iron_sword": 90, "iron_axe": 120, "gold_sword": 180, "silver_armor": 170, "steel_armor": 150},
    },
    "ruins_relics": {
        "name": "Iora's Relics",
        "items": {"stamina_tonic": 28, "traveler_bow": 110, "minor_potion": 24},
    },
    "hidden_rare": {
        "name": "Fen's Hidden Goods",
        "items": {"traveler_bow": 130, "iron_sword": 120, "hearty_stew": 35},
    },
    "east_village_goods": {
        "name": "Talia's Wares",
        "items": {"eastern_herb": 16, "fish": 12, "minor_potion": 20, "traveler_bow": 100},
    },
    "harbor_goods": {
        "name": "Lynn's Harbor Goods",
        "items": {"fish": 10, "seaweed": 8, "minor_potion": 18, "traveler_bow": 95, "hearty_stew": 28},
    },
    "southern_forge": {
        "name": "Thane's Southern Forge",
        "items": {"iron_sword": 100, "steel_armor": 150, "minor_potion": 25, "stamina_tonic": 30},
    },
    "desert_trader": {
        "name": "Mira's Desert Wares",
        "items": {"desert_herb": 20, "cactus_fruit": 12, "minor_potion": 22, "traveler_bow": 115, "sandstone_amulet": 80},
    },
}

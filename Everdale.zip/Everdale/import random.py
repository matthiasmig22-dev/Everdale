import random

print ("Welcome")
print ("do you want to murder somone with a ak-47")